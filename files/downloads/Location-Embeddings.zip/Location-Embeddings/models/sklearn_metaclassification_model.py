from collections import Counter, defaultdict
from copy import deepcopy

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sn
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score
from sklearn.model_selection import KFold
from sklearn.svm import SVC

from util import util
from util.enums import ClassificationLevel, MetaClassifier


class SKLearnMetaClassificationModel:
    def __init__(self, model, detailed_output=False, task=None, classification_level=ClassificationLevel.STUDENT,
                 meta_classifier=MetaClassifier.INDIVIDUAL_KEY_SVM, dte_instance_str=None, class_weight=None,
                 embeddings=None):
        self.model = model
        self.detailed_output = detailed_output
        self.meta_classifier = SVC(kernel='linear', class_weight=class_weight)
        self.meta_classifier_type = meta_classifier
        self.all_outputs = None
        self.all_inputs = None
        self.task = task
        self.classification_level = classification_level
        self.dte_instance_str = dte_instance_str
        self.embeddings = embeddings

        self.validate_meta_predictions_by_fold = {}
        self.test_meta_predictions_by_fold = {}
        self.validate_all_predictions_by_fold = {}
        self.test_all_predictions_by_fold = {}

    def train(self, student_vectors, student_outputs):
        self.all_outputs = sorted(list(set(student_outputs.values())))
        # this is all of the days/weeks/months that are included in the input data
        self.all_inputs = sorted(set().union(*[list(stu.keys()) for stu in list(student_vectors.values())]))
        X, y, _ = self._build_input_arrays(student_vectors, student_outputs)
        self.model.fit(X, y)

        most_common = Counter(y).most_common()[0]
        baseline = most_common[1] / len(y)
        print('Baseline:', baseline)

        # now also train meta-classifier if necessary

        if self.classification_level == ClassificationLevel.STUDENT and \
                self.meta_classifier_type != MetaClassifier.VOTING:
            meta_inputs = []
            meta_outputs = []
            for train_hash in student_vectors.keys():
                p = self.model.predict(np.array(list(student_vectors[train_hash].values())))
                if self.meta_classifier_type == MetaClassifier.INDIVIDUAL_KEY_SVM:
                    meta_inputs.append(self._build_meta_input_individual_keys(self.all_outputs, p, self.all_inputs,
                                                                              student_vectors[train_hash].keys()))
                meta_outputs.append(student_outputs[train_hash])
            self.meta_classifier.fit(np.array(meta_inputs), np.array(meta_outputs))

    def test(self, student_vectors, student_outputs, fold=None, validation=False):
        predictions = []
        y = []
        meta_predictions_by_student = {}
        all_predictions_by_student = {}
        for test_hash in student_vectors.keys():
            if student_outputs[test_hash] not in self.all_outputs:
                # filter out students who do not fit within the classification scheme due to lack of data
                # there are some classes in the data that we do not have enough information to train on, like 5th year
                # students or arts majors
                continue
            p = self.model.predict(np.array(list(student_vectors[test_hash].values())))
            if self.classification_level == ClassificationLevel.REPRESENTATION_LEVEL:
                predictions.extend(p)
                for i in range(len(p)):
                    y.append(student_outputs[test_hash])
                all_predictions_by_student[test_hash] = p
            else:
                prediction = None
                if self.meta_classifier_type == MetaClassifier.VOTING:
                    top_count = 0
                    most_common_labels = []
                    for label, count in Counter(p).most_common():
                        if count >= top_count:
                            most_common_labels.append(label)
                            top_count = count
                    prediction = np.random.choice(most_common_labels)

                elif self.meta_classifier_type == MetaClassifier.INDIVIDUAL_KEY_SVM:
                    prediction = self.meta_classifier.predict(
                        np.array([self._build_meta_input_individual_keys(self.all_outputs, p, self.all_inputs,
                                                                         student_vectors[test_hash].keys())]))[0]
                predictions.append(prediction)
                y.append(student_outputs[test_hash])
                meta_predictions_by_student[test_hash] = prediction
                all_predictions_by_student[test_hash] = p

        if fold is None:
            util.save_test_output(self.dte_instance_str, predictions, y, {0: all_predictions_by_student},
                                  {0: meta_predictions_by_student})
        else:
            # save to instance variables, write back at end
            if validation:
                self.validate_meta_predictions_by_fold[fold] = meta_predictions_by_student
                self.validate_all_predictions_by_fold[fold] = all_predictions_by_student
            else:
                self.test_meta_predictions_by_fold[fold] = meta_predictions_by_student
                self.test_all_predictions_by_fold[fold] = all_predictions_by_student

        f_score = f1_score(y, predictions, average='macro')
        accuracy = accuracy_score(y, predictions)

        if self.detailed_output:
            most_common = Counter(y).most_common()[0]
            average_type = 'macro'
            print('Majority class ({})\t{}'.format(most_common[0], most_common[1] / len(y)))
            print('Using {} average'.format(average_type))
            print('Precision\t{}'.format(precision_score(y, predictions, average=average_type)))
            print('Recall\t{}'.format(recall_score(y, predictions, average=average_type)))
            print('F1 Score\t{}'.format(f1_score(y, predictions, average=average_type)))
        print('Accuracy Test\t{}'.format(accuracy_score(y, predictions)))

        print('Contingency:')
        print(pd.crosstab(pd.Series(y), pd.Series(predictions), rownames=['True'], colnames=['Predicted']))

        class_accuracies = {}
        for output in self.all_outputs:
            class_predictions = [x for i, x in enumerate(predictions) if y[i] == output]
            class_accuracy = sum(1 for p in class_predictions if p == output) / len(class_predictions)
            class_accuracies[output] = class_accuracy

        return accuracy, f_score, class_accuracies, y, predictions

    def cv(self, student_vectors, student_outputs, folds=5):
        all_outputs = sorted(list(set(student_outputs.values())))
        # this is all of the days/weeks/months that are included in the input data
        all_inputs = sorted(set().union(*[list(stu.keys()) for stu in list(student_vectors.values())]))
        hashes = np.array(list(student_vectors.keys()))
        if folds == -1:
            # if folds is -1, use leave-one-out CV
            folds = len(hashes)
        predictions = []
        meta_predictions_by_fold = defaultdict(dict)
        all_predictions_by_fold = defaultdict(dict)
        y = []
        kf = KFold(folds)
        X_all, y_all, hash_indices = self._build_input_arrays(student_vectors, student_outputs)
        models = []
        for fold_id, (train_fold, test_fold) in enumerate(kf.split(hashes)):
            X_train, y_train = self._build_input_output(X_all, y_all, hash_indices, hashes[train_fold])
            self.model.fit(X_train, y_train)
            models.append(deepcopy(self.model))
            # train meta-classifier: predict for each hash's vectors, then train to predict correct final output
            if self.classification_level == ClassificationLevel.STUDENT and \
                    self.meta_classifier_type != MetaClassifier.VOTING:
                meta_inputs = []
                meta_outputs = []
                for train_hash in hashes[train_fold]:
                    p = self.model.predict(np.array(list(student_vectors[train_hash].values())))
                    if self.meta_classifier_type == MetaClassifier.INDIVIDUAL_KEY_SVM:
                        meta_inputs.append(self._build_meta_input_individual_keys(all_outputs, p, all_inputs,
                                                                                  student_vectors[train_hash].keys()))
                    meta_outputs.append(student_outputs[train_hash])
                self.meta_classifier.fit(np.array(meta_inputs), np.array(meta_outputs))

            for test_hash in hashes[test_fold]:
                p = self.model.predict(np.array(list(student_vectors[test_hash].values())))
                if self.classification_level == ClassificationLevel.REPRESENTATION_LEVEL:
                    predictions.extend(p)
                    for i in range(len(p)):
                        y.append(student_outputs[test_hash])
                else:
                    if self.meta_classifier_type == MetaClassifier.VOTING:
                        top_count = 0
                        most_common_labels = []
                        for label, count in Counter(p).most_common():
                            if count >= top_count:
                                most_common_labels.append(label)
                                top_count = count
                        predictions.append(np.random.choice(most_common_labels))

                    elif self.meta_classifier_type == MetaClassifier.INDIVIDUAL_KEY_SVM:
                        predictions.append(self.meta_classifier.predict(
                            np.array([self._build_meta_input_individual_keys(all_outputs, p, all_inputs,
                                                                             student_vectors[test_hash].keys())])
                        )[0])
                    y.append(student_outputs[test_hash])

                meta_predictions_by_fold[fold_id][test_hash] = predictions[-1]
                all_predictions_by_fold[fold_id][test_hash] = p
        accuracy = accuracy_score(y, predictions)
        f_score = f1_score(y, predictions, average='macro')
        most_common = Counter(y).most_common()[0]
        if self.detailed_output:
            cm = pd.crosstab(pd.Series(y), pd.Series(predictions), rownames=['True'], colnames=['Predicted'])
            sn.heatmap(cm, annot=True)
            plt.title('Confusion Matrix for {} Prediction'.format(self.task))
            plt.show()
        baseline = most_common[1] / len(y)

        util.save_test_output(self.dte_instance_str, predictions, y, all_predictions_by_fold,
                              meta_predictions_by_fold)
        util.save_models(self.dte_instance_str, models, self.embeddings)

        print('Contingency:')
        print(pd.crosstab(pd.Series(y), pd.Series(predictions), rownames=['True'], colnames=['Predicted']))

        class_accuracies = {}
        for output in all_outputs:
            class_predictions = [x for i, x in enumerate(predictions) if y[i] == output]
            class_accuracy = sum(1 for p in class_predictions if p == output) / len(class_predictions)
            class_accuracies[output] = class_accuracy

        return accuracy, f_score, baseline, class_accuracies

    def cv_all(self, student_vector_map, student_outputs, dte_instance, include_validation_fold=False, n_folds=10):
        fold_id_map = util.get_folds(n_folds)
        test_overall_gold_standard = []
        validate_overall_gold_standard = []
        test_overall_predictions = []
        validate_overall_predictions = []
        models = []
        for i in range(n_folds):
            # compute ids that will be used for test and for validate
            validate_ids = set(fold_id_map[i]) if include_validation_fold else set()
            test_ids = set(fold_id_map[(i + 1) % 10])
            print(validate_ids)

            # separate vectors and outputs to train/dev/test for this fold
            train_vector_map = {k: v for k, v in student_vector_map.items() if k not in validate_ids and k not in test_ids}
            validate_vector_map = {k: v for k, v in student_vector_map.items() if k in validate_ids}
            test_vector_map = train_vector_map

            train_outputs = {k: v for k, v in student_outputs.items() if k not in validate_ids and k not in test_ids}
            validate_outputs = {k: v for k, v in student_outputs.items() if k in validate_ids}
            test_outputs = train_outputs

            self.train(train_vector_map, train_outputs)
            _, _, _, fold_gold_standard, fold_predictions = self.test(test_vector_map, test_outputs, fold=i)
            models.append(deepcopy(self.model))
            test_overall_gold_standard.extend(fold_gold_standard)
            test_overall_predictions.extend(fold_predictions)

            if include_validation_fold:
                _, _, _, fold_gold_standard, fold_predictions = self.test(validate_vector_map, validate_outputs, fold=i,
                                                                          validation=True)
                validate_overall_gold_standard.extend(fold_gold_standard)
                validate_overall_predictions.extend(fold_predictions)

        if dte_instance.test:
            overall_gold_standard = test_overall_gold_standard
            overall_predictions = test_overall_predictions
        else:
            overall_gold_standard = validate_overall_gold_standard
            overall_predictions = validate_overall_predictions

        accuracy = accuracy_score(overall_gold_standard, overall_predictions)
        f_score = f1_score(overall_gold_standard, overall_predictions, average='macro')
        most_common = Counter(overall_gold_standard).most_common()[0]
        if self.detailed_output:
            cm = pd.crosstab(pd.Series(overall_gold_standard), pd.Series(overall_predictions),
                             rownames=['True'], colnames=['Predicted'])
            sn.heatmap(cm, annot=True)
            plt.title('Confusion Matrix for {} Prediction'.format(self.task))
            plt.show()
        baseline = most_common[1] / len(overall_gold_standard)

        print('Contingency:')
        print(pd.crosstab(pd.Series(overall_gold_standard), pd.Series(overall_predictions),
                          rownames=['True'], colnames=['Predicted']))

        class_accuracies = {}
        for output in set(overall_gold_standard):
            class_predictions = [x for i, x in enumerate(overall_predictions) if overall_gold_standard[i] == output]
            class_accuracy = sum(1 for p in class_predictions if p == output) / len(class_predictions)
            class_accuracies[output] = class_accuracy

        # save both test and validation results
        prev_test = dte_instance.test
        dte_instance.test = False
        if include_validation_fold:
            util.save_test_output(str(dte_instance), validate_overall_predictions, validate_overall_gold_standard,
                                  self.validate_all_predictions_by_fold, self.validate_meta_predictions_by_fold)
        dte_instance.test = True
        util.save_test_output(str(dte_instance), test_overall_predictions, test_overall_gold_standard,
                              self.test_all_predictions_by_fold, self.test_meta_predictions_by_fold)
        util.save_models(self.dte_instance_str, models, self.embeddings)
        dte_instance.test = prev_test


        return accuracy, f_score, baseline, class_accuracies



    @staticmethod
    def get_and_print_classification_stats(unlabeled_predictions, unlabeled_outputs):
        most_common = Counter(unlabeled_outputs).most_common()[0]
        baseline = most_common[1] / len(unlabeled_outputs)

        accuracy = accuracy_score(unlabeled_outputs, unlabeled_predictions)
        f_score = f1_score(unlabeled_outputs, unlabeled_predictions, average='macro')


        print('Contingency:')
        print(pd.crosstab(pd.Series(unlabeled_outputs), pd.Series(unlabeled_predictions),
                          rownames=['True'], colnames=['Predicted']))

        class_accuracies = {}
        for output in set(unlabeled_outputs):
            class_predictions = [x for i, x in enumerate(unlabeled_predictions) if unlabeled_outputs[i] == output]
            class_accuracy = sum(1 for p in class_predictions if p == output) / len(class_predictions)
            class_accuracies[output] = class_accuracy

        return accuracy, f_score, baseline, class_accuracies


    @staticmethod
    def _build_input_output(X, y, hash_indices, fold_hashes):
        fold_indices = []
        for i, student_hash in enumerate(fold_hashes):
            start_index = hash_indices[student_hash][0]
            end_index = hash_indices[student_hash][1]
            fold_indices.extend(list(range(start_index, end_index)))
        indices_arr = np.array(fold_indices)
        return X[indices_arr], y[indices_arr]

    @staticmethod
    def _build_input_arrays(student_vectors, student_outputs):
        X = []
        y = []
        hash_indices = {}
        for stu_hash in student_vectors.keys():
            start_id = len(X)
            X.extend(student_vectors[stu_hash].values())
            y.extend([student_outputs[stu_hash]] * len(student_vectors[stu_hash]))
            end_id = len(X)
            hash_indices[stu_hash] = (start_id, end_id)
        return np.asarray(X), np.asarray(y), hash_indices


    @staticmethod
    def _build_meta_input_individual_keys(all_outputs, prediction, all_inputs, input_keys):
        """
        The individual keys meta-classifier takes in a value for each key, where keys are numbers representing months,
        weeks, or days
        """
        keys_index = list(input_keys)
        meta_input = []
        for input_time in all_inputs:
            if input_time in keys_index:
                for output in all_outputs:
                    if output == prediction[keys_index.index(input_time)]:
                        meta_input.append(1)
                    else:
                        meta_input.append(0)
            else:
                meta_input.extend([0] * len(all_outputs))
        return np.array(meta_input)
