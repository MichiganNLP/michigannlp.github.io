import re
from collections import namedtuple

import gensim
import numpy as np

from util.enums import PretrainedEmbeddingType

EMBEDDING_PATH = {
    PretrainedEmbeddingType.GLOVE_TWITTER: 'resources/glove.twitter.27B/glove.twitter.27B.200d.txt',
}


def load(embedding_type):
    print('Loading embeddings...')
    EmbeddingModel = namedtuple('EmbeddingModel', ['vector_size', 'vectors'])
    if embedding_type == PretrainedEmbeddingType.GLOVE_TWITTER:
        # I expect that this might give the best results on social media data like twitter_geo/reddit data
        # code based loosely on https://stackoverflow.com/questions/37793118/load-pretrained-glove-vectors-in-python
        vectors = {}
        with open(EMBEDDING_PATH[embedding_type]) as f:
            dim = int(re.match(r'.*\.([0-9]+)d.txt', EMBEDDING_PATH[embedding_type]).group(1))
            for line in f:
                split = line.rsplit(maxsplit=dim)
                vectors[split[0]] = np.array([float(val) for val in split[1:]])
        model = EmbeddingModel(vector_size=dim, vectors=vectors)
    else:
        raise Exception("Only loads glove twitter embeddings")
    print('Finished loading embeddings')
    return model
