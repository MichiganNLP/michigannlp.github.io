from enum import Enum, auto

class ArgparseEnum(Enum):
    """
    This is a class used to create enums that can easily be used as argparse arguments
    Inspired by https://stackoverflow.com/questions/43968006/support-for-enum-arguments-in-argparse
    """
    def __str__(self):
        return self.name.lower()

    @classmethod
    def from_string(cls, s):
        if s.upper() in cls.__members__:
            return cls[s.upper()]
        else:
            raise ValueError()

class BuildingTextEmbeddingType(ArgparseEnum):
    TFIDF_PRETRAINED = auto()

class ClassificationLevel(ArgparseEnum):
    REPRESENTATION_LEVEL = auto()
    STUDENT = auto()

class MetaClassifier(ArgparseEnum):
    INDIVIDUAL_KEY_SVM = auto()
    VOTING = auto()

class PretrainedEmbeddingType(ArgparseEnum):
    GLOVE_TWITTER = auto()

class RepresentationLevel(ArgparseEnum):
    DAY = auto()
    MONTH = auto()
    STUDENT = auto()
    WEEK = auto()

class Semester(ArgparseEnum):
    FALL_2018 = auto()
    WINTER_2018 = auto()
    WINTER_2019 = auto()

class TextType(ArgparseEnum):
    CAMPUS_INFO = auto()
    REDDIT_MENTION = auto()
    TWITTER_GEO = auto()

class VectorMethod(ArgparseEnum):
    WEIGHTED_AVERAGE = auto()
    WEIGHTED_AVERAGE_IGNORE_SHORT = auto()
