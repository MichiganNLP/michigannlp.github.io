import calendar
import datetime
import os
from collections import defaultdict, Counter

import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta

from util import util, Semester, N_ITEMS, word_in_embeddings, get_word, normalize_array
from util.enums import VectorMethod, RepresentationLevel


def get_student_vectors(embeddings, student_hash, building_functionality_map, vector_method, representation_level,
                        semester, student_data_path, normalize=False):
    if type(embeddings) == pd.core.frame.DataFrame:
        vector_size = embeddings.shape[0]
    elif type(embeddings) == dict:
        vector_size = len(list(embeddings.values())[0])
    else:
        vector_size = embeddings.vector_size

    # read data, either with individual hours or with specific location visits
    trail = pd.read_csv(os.path.join(student_data_path, student_hash, 'trail.csv'))
    all_locations = defaultdict(list)
    for row in trail.itertuples():
        location = row.Location
        functionality = building_functionality_map[location][0]
        if word_in_embeddings(embeddings, location) and \
                (location in building_functionality_map):
            parsed_time = datetime.datetime.strptime(row[4], '%Y-%m-%d %H:%M:%S')
            location_tuple = (location, float(row.Duration), parsed_time, functionality)
            _add_to_location_map_at_level(all_locations, representation_level, location_tuple, parsed_time,
                                          vector_method=vector_method)

    if vector_method == VectorMethod.WEIGHTED_AVERAGE or vector_method == VectorMethod.WEIGHTED_AVERAGE_IGNORE_SHORT:
        output = {}
        output_sequences = defaultdict(list)
        for time, location_list in all_locations.items():
            vectors = []
            weights = []
            for location, duration, parsed_time, functionality in location_list:
                vectors.append(get_word(embeddings, location))
                weights.append(duration)
                output_sequences[time].append(location)
            output[time] = normalize_array(np.average(vectors, weights=weights, axis=0), normalize)
        return output, output_sequences


def _add_to_location_map_at_level(location_map, representation_level, location_representation, end_time,
                                  vector_method=None):
    # figure out of connection spans multiple connections
    split_span = vector_method not in {VectorMethod.WEIGHTED_AVERAGE}
    end_time_representation = _get_time_at_representation_level(end_time, representation_level)
    duration = location_representation[1]

    if not split_span or duration == 0 or representation_level == RepresentationLevel.STUDENT:
        location_map[end_time_representation].append(location_representation)
        return

    if duration < 600 and vector_method == VectorMethod.WEIGHTED_AVERAGE_IGNORE_SHORT:
        return

    start_time = end_time - datetime.timedelta(seconds=duration)
    start_time_representation = _get_time_at_representation_level(start_time, representation_level)

    appended = 0
    total_duration = 0
    time_representation = start_time_representation
    prev_start = start_time
    n_iters = _get_n_iters(start_time.year, start_time_representation, end_time_representation, representation_level)
    for i in range(n_iters):
        next_start = _get_next_time_start(prev_start, representation_level)
        # convert time representataion to use the proper duration
        if start_time_representation == end_time_representation:
            new_duration = duration
        elif time_representation == start_time_representation:
            new_duration = (next_start - start_time).total_seconds()
        elif time_representation == end_time_representation:
            new_duration = (end_time - prev_start).total_seconds()
        else:
            # in this case, we are between the start and end representations
            new_duration = (next_start - prev_start).total_seconds()
        prev_start = next_start
        total_duration += new_duration

        new_representation = (location_representation[0], new_duration, location_representation[2],
                              location_representation[3])
        # add to map
        location_map[time_representation].append(new_representation)

        # get next time representation
        time_representation = _get_next_time_representation(start_time, time_representation, representation_level)
        appended += 1

    # sanity checks because working with dates is shockingly hard
    if start_time_representation == end_time_representation:
        assert(appended == 1)
    assert(total_duration == duration)


def _get_next_time_start(curr_start, representation_level):
    if representation_level == RepresentationLevel.MONTH:
        return datetime.datetime.combine((curr_start.replace(day=1) + relativedelta(months=1)), datetime.time())
    elif representation_level == RepresentationLevel.WEEK:
        start_dt = curr_start + datetime.timedelta(weeks=1) - datetime.timedelta(days=(curr_start.isoweekday() - 1))
        return datetime.datetime.combine(start_dt, datetime.time())
    elif representation_level == RepresentationLevel.DAY:
        day_start = datetime.datetime.combine(curr_start, datetime.time())
        return day_start + datetime.timedelta(days=1)


def _get_n_iters(year, start_time_representation, end_time_representation, representation_level):
    # this is the common case
    if end_time_representation >= start_time_representation:
        return (end_time_representation - start_time_representation) + 1

    # this is the less common but more challenging case, where we "loop" around the numbers that represent our
    # days/weeks/months (year changes while student is connected to wifi)
    if representation_level == RepresentationLevel.MONTH:
        return (12 - start_time_representation + end_time_representation) + 1
    elif representation_level == RepresentationLevel.WEEK:
        # suggestions for working with iso weeks from
        # https://stackoverflow.com/questions/29262859/the-number-of-calendar-weeks-in-a-year
        n_weeks = datetime.date(year, 12, 28).isocalendar()[1]
        return (n_weeks - start_time_representation + end_time_representation) + 1
    elif representation_level == RepresentationLevel.DAY:
        n_days = 366 if calendar.isleap(year) else 365
        return (n_days - start_time_representation + end_time_representation) + 1


def _get_next_time_representation(start_time, time_representation, representation_level):
    if representation_level == RepresentationLevel.MONTH:
        return (time_representation % 12) + 1
    elif representation_level == RepresentationLevel.WEEK:
        # suggestions for working with iso weeks from
        # https://stackoverflow.com/questions/29262859/the-number-of-calendar-weeks-in-a-year
        n_weeks = datetime.date(start_time.year, 12, 28).isocalendar()[1]
        return (time_representation % n_weeks) + 1
    elif representation_level == RepresentationLevel.DAY:
        n_days = 366 if calendar.isleap(start_time.year) else 365
        return (time_representation % n_days) + 1


def _get_time_at_representation_level(time, representation_level):
    if representation_level == RepresentationLevel.MONTH:
        return time.month
    elif representation_level == RepresentationLevel.WEEK:
        return time.isocalendar()[1]
    elif representation_level == RepresentationLevel.DAY:
        return time.timetuple().tm_yday
    elif representation_level == RepresentationLevel.STUDENT:
        # just use 0 as a baseline for full student representation
        return 0
