import datetime
import hashlib
import json
import os
import pickle
import uuid
from collections import Counter, namedtuple, defaultdict

import numpy as np
import pandas as pd
from gensim.models import Word2Vec
from numpy import nan
from sklearn.preprocessing import normalize

from util import config
from util.config import Semester, GENDER_QUESTION_ID, UNDERGRADUATE_SCHOOL_QUESTION_ID, CLASS_YEAR_QUESTION_ID, \
    CUMULATIVE_GPA_QUESTION_ID
from util.survey_utils import add_survey_num_to_col_name, add_depression_columns, fill_missing_depression_columns

CATEGORICAL_QUESTIONS = [GENDER_QUESTION_ID, UNDERGRADUATE_SCHOOL_QUESTION_ID, CLASS_YEAR_QUESTION_ID]
NO_CONVERSION_QUESTIONS = [CUMULATIVE_GPA_QUESTION_ID]

MODEL_STORAGE_CONFIG = '{}/config/model_args_to_filename.csv'.format(config.PICKLE_DIR)
DTE_RESULTS_CONFIG = '{}/config/dte_instance_to_file_id.csv'.format(config.PICKLE_DIR)


def build_hour_chunks(df, semester, include_unknown=True, student_id=None):
    pickle_file = '{}/hour_chunks/{}_{}_{}.pickle'.format(config.PICKLE_BASE_DIR, student_id, semester,
                                                          include_unknown)

    if os.path.exists(pickle_file) and student_id is not None:
        with open(pickle_file, 'rb') as f:
            return pickle.load(f)

    Location = namedtuple('Location', ['start_time', 'end_time', 'time_spent', 'location'])
    # add one to make this inclusive of end_date
    start_date = config.LOCATION_DATES[semester]['START_DATE']
    end_date = config.LOCATION_DATES[semester]['END_DATE']

    num_days = (end_date - start_date).days + 1
    hours = [datetime.timedelta(hours=i) for i in range(24)]
    days = [start_date + datetime.timedelta(days=i) for i in range(num_days)]
    locations = []

    for index, row in df.iterrows():
        end_time = datetime.datetime.strptime(row['Stop Time'], '%Y-%m-%d %H:%M:%S')
        time_spent = datetime.timedelta(seconds=row['Duration'])
        start_time = end_time - time_spent
        locations.append(Location(start_time=start_time, end_time=end_time, time_spent=time_spent,
                                  location=row['Location']))


    # build list of restricted words that should be included in the vocab
    restricted_words = set()
    start_index = 0
    sequence = []
    for day in days:
        for hour in hours:
            chunk_start = day + hour
            location, start_index, duration = _get_location_for_time_chunk(chunk_start, locations, start_index)
            if include_unknown or location != 'UNKNOWN':
                sequence.append(location)
                restricted_words.add(location)

    if student_id is not None:
        pickle_write_secure(pickle_file, (sequence, restricted_words))

    return sequence, restricted_words


def _get_location_for_time_chunk(chunk_start, locations, start_index):
    # this is not the most efficient way to do this, but shrug it works
    chunk_end = chunk_start + datetime.timedelta(hours=1)
    overlap_locations = Counter()
    new_start = None
    for i in range(start_index, len(locations)):
        location = locations[i]
        if location.time_spent < datetime.timedelta(minutes=10):
            # if less than 10 minutes are spent at a location, the connection may not mean that the student actually
            # spent time there
            continue
        if location.start_time < chunk_start and location.end_time > chunk_end:
            # this is the entirely within option
            # if this is true, then this is the only possible location so we can just return early
            return location.location, i, location.time_spent.total_seconds()
        elif location.start_time < chunk_end and location.end_time > chunk_start:
            # in this case there may be multiple locations for this time chunk
            if new_start is None:
                new_start = i
            overlap_locations[location] = min(chunk_end, location.end_time) - max(location.start_time, chunk_start)
        elif location.start_time > chunk_end:
            # there is no possible overlap here or after, so break the loop
            if new_start is None:
                new_start = i
            break

    if new_start is None:
        # in this case we have run off the end of the locations list
        return 'UNKNOWN', len(locations) - 1, 3600

    if len(overlap_locations) == 0:
        return 'UNKNOWN', new_start, 3600
    else:
        return overlap_locations.most_common(1)[0][0].location, new_start, \
               overlap_locations.most_common(1)[0][0].time_spent.total_seconds()


def read_larc_data(semester, larc_data_type, dedup=False, term_only=True):
    data_paths = get_config(semester)
    larc_path = data_paths['LARC'][larc_data_type]
    if semester == Semester.WINTER_2018:
        larc_term_dt = config.WINTER_2018_LARC_TERM_DT
    elif semester == Semester.FALL_2018:
        larc_term_dt = config.FALL_2018_LARC_TERM_DT
    elif semester == Semester.WINTER_2019:
        larc_term_dt = config.WINTER_2019_LARC_TERM_DT
    else:
        raise Exception('Semester {} not supported'.format(semester))

    # read and process LARC dataframe, involving
    # 1. filter larc data for correct term --> this means pulling the most recent dump of data for the specified term
    # 2. complete mapping to include sha1_hash in the dataframe, so it can be joined with the survey data
    larc_dataframe = pd.read_csv(larc_path, low_memory=False)
    # this is needed to remove unnecessary spaces from column names
    larc_dataframe.columns = [col.strip() for col in larc_dataframe.columns]
    max_date_larc = datetime.datetime.strftime(max(larc_dataframe['SNPSHT_RPT_DT'].apply(
        lambda x: datetime.datetime.strptime(x, '%d-%b-%y'))), '%d-%b-%y').upper()

    # filter our THIS SEMESTER only if the term_only flag is set
    # we may want to, for example, get all of the courses a student has ever enrolled in
    if 'term' in larc_data_type and term_only:
        larc_dataframe = larc_dataframe[larc_dataframe['TERM_SHORT_DES'] == larc_term_dt]

    larc_dataframe = larc_dataframe[larc_dataframe['SNPSHT_RPT_DT'] == max_date_larc]
    if 'sha1_hash' not in larc_dataframe.columns:
        larc_mapping = data_paths['LARC']['mapping']
        larc_mapping_dataframe = pd.read_csv(larc_mapping)
        larc_dataframe = pd.merge(larc_dataframe, larc_mapping_dataframe, left_on='STDNT_ID', right_on='PRSN_ID')

    # drop index column
    if 'Unnamed: 0' in larc_dataframe.columns:
        larc_dataframe.drop(columns=['Unnamed: 0'], inplace=True)

    if dedup:
        # drop LARC duplicates
        if 'class' in larc_data_type:
            larc_dataframe.drop_duplicates(inplace=True)
        else:
            larc_dataframe.drop_duplicates(subset=['sha1_hash'], inplace=True)

    return larc_dataframe


def read_survey_data(semester, survey=1):
    data_paths = get_config(semester)
    survey_path = data_paths['SURVEY_{}'.format(survey)]

    # read and process survey dataframe
    # pull column IDs out of tuple - I don't like using eval, but it is the clearest way to process this data
    survey_dataframe = pd.read_csv(survey_path)
    survey_dataframe.columns = survey_dataframe.columns.to_series().apply(lambda x: eval(x)[0] if x[0] == '(' else x)

    # add depression data
    add_depression_columns(survey_dataframe)

    if survey != 1:
        # remove incomplete data
        survey_dataframe = survey_dataframe[survey_dataframe['Finished'] == 1]
        # rename columns
        survey_dataframe.columns = survey_dataframe.columns.to_series().apply(lambda x:
                                                                              add_survey_num_to_col_name(x, survey))

    return survey_dataframe


def load_student_data_by_semester(semester, hashes=None, additional_surveys=False):
    survey_dataframe = read_survey_data(semester)

    if hashes is not None:
        survey_dataframe = survey_dataframe[survey_dataframe['sha1_hash'].isin(hashes)]

    larc_dataframe = read_larc_data(semester, 'term_info', dedup=True)
    # merge the survey and LARC data into a single dataframe
    student_dataframe = pd.merge(survey_dataframe, larc_dataframe, left_on='sha1_hash', right_on='sha1_hash')
    if hashes is not None:
        student_dataframe = student_dataframe[student_dataframe['sha1_hash'].isin(hashes)]

    if additional_surveys:
        available_surveys = [4]
        for survey in available_surveys:
            additional_survey_data = read_survey_data(semester, survey=survey)
            # NOTE: this removes students who have not completed ALL surveys
            student_dataframe = pd.merge(student_dataframe, additional_survey_data, how='left')

        # fill in depression data on additional surveys - i.e. if undefined, set to survey 1 result
        fill_missing_depression_columns(student_dataframe)

    return student_dataframe


def filter_and_balance_dataset(student_data, question_id, reduction_function=None, inclusion_function=None,
                               inclusion_only=False, filter_none=False):
    student_data = student_data.sample(frac=1, random_state=10)
    copied = student_data.copy(deep=True)
    if reduction_function is not None:
        copied[question_id] = copied[question_id].apply(reduction_function)
    if inclusion_function is not None:
        copied = copied[copied[question_id].apply(inclusion_function)]
    if filter_none:
        assert inclusion_only
        copied = copied[copied[question_id].notna()]
    min_value = min(copied[question_id].value_counts().values)
    count_by_value = Counter()
    indices = []
    for index, row in copied.iterrows():
        val = row[question_id]
        # either balance or just use the inclusion function
        if count_by_value[val] < min_value or inclusion_only:
            indices.append(index)
        count_by_value[row[question_id]] += 1
    return student_data.loc[indices].reset_index(drop=True)


def get_all_functionalities(building_functionality_map, single):
    if single:
        s = set(building_functionality_map.values())
    else:
        s = set([val[0] for val in building_functionality_map.values()])
    s.discard(nan)
    return list(s)


def _clean_functionality(functionality):
    if type(functionality) != str:
        return functionality
    return functionality.replace(' ', '')


def get_functionalities(single=False):
    f = 'data/referred_buildings.csv'
    df = pd.read_csv(f)
    building_functionality_map = {}
    for row in df.itertuples():
        if single:
            building_functionality_map[row.BuildingName] = _clean_functionality(row.Primary)
        else:
            building_functionality_map[row.BuildingName] = [_clean_functionality(row.Primary),
                                                            _clean_functionality(row.Secondary)]
    functionalities = get_all_functionalities(building_functionality_map, single)
    buildings = list(building_functionality_map.keys())
    return building_functionality_map, functionalities, buildings


def get_numerical_text_map():
    with open(config.NUMERICAL_TEXT_MAP) as jsonfile:
        return json.load(jsonfile)


def get_config(semester):
    if semester == Semester.WINTER_2018:
        return config.WINTER_2018_DATA_PATHS
    elif semester == Semester.FALL_2018:
        return config.FALL_2018_DATA_PATHS
    elif semester == Semester.WINTER_2019:
        return config.WINTER_2019_DATA_PATHS
    else:
        raise Exception('Semester {} not supported in config'.format(semester))


def get_location_csv_paths(semester=None):
    csv_paths = []

    if semester is None and config.N_SEMESTERS == 3:
        # if no semester is provided, get all paths
        location_paths = [config.WINTER_2018_LOCATION_DATA_PATH, config.FALL_2018_LOCATION_DATA_PATH,
                          config.WINTER_2019_LOCATION_DATA_PATH]
    elif semester is None:
        location_paths = [config.WINTER_2018_LOCATION_DATA_PATH, config.FALL_2018_LOCATION_DATA_PATH]
    elif semester == Semester.WINTER_2018:
        location_paths = [config.WINTER_2018_LOCATION_DATA_PATH]
    elif semester == Semester.FALL_2018:
        location_paths = [config.FALL_2018_LOCATION_DATA_PATH]
    elif semester == Semester.WINTER_2019:
        location_paths = [config.WINTER_2019_LOCATION_DATA_PATH]
    else:
        raise Exception('Unknown semester')
    for path in location_paths:
        csv_paths.extend(os.path.join(path, s_id, 'trail.csv') for s_id in os.listdir(path))
    return csv_paths


def read_hashes(semester, train=True):
    path_config = get_config(semester)
    hash_path = path_config['TRAIN_IDS'] if train else path_config['TEST_IDS']
    with open(hash_path) as f:
        return f.read().splitlines()


def get_hashes_by_semester(train=False, test=False):
    if not train and not test:
        raise Exception('Caller must request train or test hashes.')
    hashes = {
        Semester.WINTER_2018: _get_semester_hashes(Semester.WINTER_2018, train=train, test=test),
        Semester.FALL_2018: _get_semester_hashes(Semester.FALL_2018, train=train, test=test),
    }
    if config.N_SEMESTERS == 3:
        hashes[Semester.WINTER_2019] = _get_semester_hashes(Semester.WINTER_2019, train=train, test=test)
    return hashes


def _get_semester_hashes(semester, train=True, test=False):
    semester_hashes = []
    if train:
        semester_hashes.extend(read_hashes(semester, train=True))
    if test:
        semester_hashes.extend(read_hashes(semester, train=False))
    return semester_hashes


def get_folds(n_folds):
    fold_to_ids = defaultdict(list)
    try:
        for semester in Semester:
            if config.N_SEMESTERS == 3 or semester != Semester.WINTER_2019:
                cv_template = get_config(semester)['CV_ID_TEMPLATE']
                for fold in range(n_folds):
                    filename = cv_template.format(fold, n_folds)
                    with open(filename, 'r') as f:
                        fold_to_ids[fold].extend(f.read().splitlines())
    except FileNotFoundError:
        raise Exception('Must generate folds (n = {}) with train_test_split.py before running classifier'.format(
            n_folds))
    return fold_to_ids


def save_word2vec_model(model, args, iteration=1):
    file_id = str(uuid.uuid4())
    filename = '{}/location_vectors/{}.pickle'.format(config.PICKLE_DIR, file_id)
    df = pd.read_csv(MODEL_STORAGE_CONFIG)

    # create row to add to
    row = []
    for column in df.columns:
        if column == 'iteration':
            row.append(iteration)
        elif column == 'file_id':
            row.append(file_id)
        else:
            row.append(getattr(args, column))

    df.loc[len(df)] = row
    df.to_csv(MODEL_STORAGE_CONFIG, index=False)

    pickle_write_secure(filename, model)
    return file_id


def get_args_with_defaults(**kwargs):
    defaults = {
        'epochs': config.DEFAULT_WORD2VEC_EPOCHS,
        'hour_chunks': config.DEFAULT_HOUR_CHUNKS,
        'negative': config.DEFAULT_WORD2VEC_NEGATIVE_SAMPLING,
        'skip_gram': config.DEFAULT_WORD2VEC_SKIP_GRAM,
        'vector_size': config.DEFAULT_WORD2VEC_VECTOR_SIZE,
        'window_size': config.DEFAULT_WORD2VEC_WINDOW_SIZE,
    }
    Args = namedtuple('Args', sorted(defaults.keys()))
    defaults.update(kwargs)
    args = Args(**defaults)
    return args


def get_word2vec_file_id(seed=1, **kwargs):
    args = get_args_with_defaults(**kwargs)
    return _get_word2vec_file_id(args, seed=seed)


def _get_word2vec_file_id(args, seed=1):
    matched_rows = pd.read_csv(MODEL_STORAGE_CONFIG)
    # change NaN to None for searching
    matched_rows = matched_rows.where(pd.notna(matched_rows), None)
    for column in matched_rows.columns:
        if column == 'iteration':
            matched_rows = matched_rows.loc[matched_rows['iteration'] == seed]
        elif column != 'file_id':
            try:
                arg_attr = getattr(args, column)
                if arg_attr is None:
                    # special case for None
                    matched_rows = matched_rows.loc[pd.isna(matched_rows[column])]
                else:
                    matched_rows = matched_rows.loc[matched_rows[column] == arg_attr]
            except:
                pass
    if len(matched_rows) == 1:
        # then read the file
        return matched_rows.iloc[0].file_id
    elif len(matched_rows) > 1:
        raise Exception('No args should match multiple files')
    return None


def try_read_word2vec_model(seed=1, **kwargs):
    if 'argparse_args' in kwargs:
        file_id = _get_word2vec_file_id(kwargs['argparse_args'], seed=seed)
    else:
        file_id = get_word2vec_file_id(seed=seed, **kwargs)
    if file_id is None:
        # if no file is found, return None and train model
        return None, None
    filename = '{}/location_vectors/{}.pickle'.format(config.PICKLE_DIR, file_id)
    with open(filename, 'rb') as f:
        return pickle.load(f), file_id


def try_read_student_embeddings(w2v_file_id, vector_method, representation_level, normalize_student_vectors):
    if w2v_file_id is not None:
        if normalize_student_vectors:
            filename = '{}/student_embeddings/{}_{}_{}_normalized.pickle'.format(
                config.PICKLE_DIR, w2v_file_id, vector_method,representation_level)
        else:
            filename = '{}/student_embeddings/{}_{}_{}.pickle'.format(config.PICKLE_DIR, w2v_file_id, vector_method,
                                                                       representation_level)
        if os.path.isfile(filename):
            with open(filename, 'rb') as f:
                return pickle.load(f)
    return None, None


def save_student_embeddings(embeddings, w2v_file_id, vector_method, representation_level):
    if w2v_file_id is not None:
        filename = '{}/student_embeddings/{}_{}_{}.pickle'.format(config.PICKLE_DIR, w2v_file_id, vector_method,
                                                                  representation_level)
        pickle_write_secure(filename, embeddings)


def save_test_output(dte_instance_str, unlabeled_predictions, unlabeled_outputs, all_predictions_by_fold,
                     meta_predictions_by_fold):
    # first, get and save a hash for the instance string
    # it is possible that there will be more than one instance for a config. if there is, the most recent one will be
    # returned later on
    file_id = str(uuid.uuid4())
    filename = '{}/saved_output_v2/{}.pickle'.format(config.PICKLE_DIR, file_id)
    df = pd.read_csv(DTE_RESULTS_CONFIG)
    df.loc[len(df)] = (file_id, dte_instance_str)
    df.to_csv(DTE_RESULTS_CONFIG, index=False)

    pickle_write_secure(
        filename, (unlabeled_predictions, unlabeled_outputs, all_predictions_by_fold, meta_predictions_by_fold))


def save_models(dte_instance_str, models, embeddings):
    instance_hash = hashlib.sha1(dte_instance_str.lower().encode("utf-8")).hexdigest()
    filename = f'{config.PICKLE_DIR}/saved_models/{instance_hash}.pickle'
    pickle_write_secure(filename, (models, embeddings))


def _get_test_output_file_id(dte_instance_str):
    df = pd.read_csv(DTE_RESULTS_CONFIG)
    file_id = None
    for row in df.itertuples():
        if row.dte_instance_str == dte_instance_str:
            file_id = row.file_id
    return file_id


def test_output_exists(dte_instance_str):
    return _get_test_output_file_id(dte_instance_str) is not None


def load_test_output(dte_instance_str):
    file_id = _get_test_output_file_id(dte_instance_str)
    filename = '{}/saved_output_v2/{}.pickle'.format(config.PICKLE_DIR, file_id)
    with open(filename, 'rb') as f:
        return pickle.load(f)


def trim_non_vocab(model, restricted_words):
    # This function is adapted from
    # https://stackoverflow.com/questions/48941648/how-to-remove-a-word-completely-from-a-word2vec-model-in-gensim
    model.init_sims()

    new_vectors = []
    new_vocab = {}
    new_index2entity = []
    new_vectors_norm = []
    new_syn0 = []

    for i in range(len(model.wv.vocab)):
        word = model.wv.index2entity[i]
        vec = model.wv.vectors[i]
        vocab = model.wv.vocab[word]
        syn0 = model.wv.syn0[i]
        vec_norm = model.wv.vectors_norm[i]
        if word in restricted_words:
            vocab.index = len(new_index2entity)
            new_index2entity.append(word)
            new_vocab[word] = vocab
            new_vectors.append(vec)
            new_syn0.append(syn0)
            new_vectors_norm.append(vec_norm)

    model.wv.vocab = new_vocab
    model.wv.vectors = np.asarray(new_vectors)
    model.wv.index2entity = new_index2entity
    model.wv.index2word = new_index2entity
    model.wv.vectors_norm = new_vectors_norm

    return model


def pickle_write_secure(filename, data):
    with open(filename, 'wb') as f:
        pickle.dump(data, f)
    os.chmod(filename, 0o600)


def word_in_embeddings(embeddings, word):
    if type(embeddings) == Word2Vec:
        return word in embeddings.wv
    else:
        return word in embeddings


def get_word(embeddings, word):
    if type(embeddings) == Word2Vec:
        return embeddings.wv[word]
    else:
        return embeddings[word]


def get_iteration_seeds():
    with open('data/iteration_seeds') as f:
        return [int(seed) for seed in f.read().splitlines()]


def normalize_array(array, should_normalize=True):
    if should_normalize:
        return normalize([array])[0]
    return array


def _one_hour_separates(prev_end, curr_start):
    n_seconds = (curr_start - prev_end).seconds
    return n_seconds > 3600


def generate_movement_lexicon(min_duration=600):
    lexicon = defaultdict(set)
    lexiconWeights = defaultdict(Counter)
    for csv_path in get_location_csv_paths():
        df = pd.read_csv(csv_path)
        prev_location = None
        prev_end = None
        for row in df.itertuples():
            if row.Duration >= min_duration:
                curr_end = datetime.datetime.strptime(row[4], '%Y-%m-%d %H:%M:%S')
                time_spent = datetime.timedelta(seconds=row.Duration)
                curr_start = curr_end - time_spent
                if row.Location != 'external' and prev_location is not None and not _one_hour_separates(prev_end, curr_start):
                    # add edge only if less than one hour separates two locations
                    lexicon[prev_location].add(row.Location)
                    lexiconWeights[prev_location][row.Location] += 1
                prev_location = row.Location
                prev_end = curr_end

    return lexicon, lexiconWeights


num_text_map = get_numerical_text_map()
