"""
This module is intended to provide utils to process surveys embedded in our LEAP survey, e.g. PHQ-8 questions
"""

import numpy as np

from util import DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID, DEPRESSION_PHQ8_SEVERITY_QUESTION_ID

DEPRESSION_QUESTIONS = {
    '1': 'Q8.1_1',
    '2': 'Q8.1_2',
    '3': 'Q8.1_3',
    '4': 'Q8.1_4',
    '5': 'Q8.1_5',
    '6': 'Q8.1_6',
    '7': 'Q8.1_7',
    '8': 'Q8.1_8',
    'effect_on_life': 'Q8.2'
}

DIAGNOSIS_TO_INT = {
    'Major Depression': 2,
    'Other Depression': 1,
    'No Depression': 0
}

INT_TO_DIAGNOSIS = {
    2: 'Major Depression',
    1: 'Other Depression',
    0: 'No Depression'
}


def _get_phq_response(survey_row, question_id):
    # gets proper question id and subtracts 1
    response = survey_row[DEPRESSION_QUESTIONS[str(question_id)]]
    if np.isnan(response):
        # there are rare nan responses, convert these to the minimum response (1)
        response = 1
    return response - 1


def _should_count_phq_row(survey_row, question_id):
    return _get_phq_response(survey_row, question_id) >= 2


def get_depression_diagnosis(survey_row, binary=True):
    first_rows = _should_count_phq_row(survey_row, 1) or _should_count_phq_row(survey_row, 2)
    count_rows = 0
    for i in range(1, 9):
        if _should_count_phq_row(survey_row, i):
            count_rows += 1

    if first_rows and count_rows >= 5:
        # diagnosis for major depression
        return 1 if binary else 2
    elif first_rows and count_rows >= 2:
        return 0 if binary else 1
    return 0


def get_depression_severity(survey_row):
    score = 0
    for i in range(1, 9):
        score += _get_phq_response(survey_row, i)
    return int(score)


def add_depression_columns(survey_df):
    survey_df[DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID] =\
        survey_df.apply(lambda row: get_depression_diagnosis(row, binary=False), axis=1)
    survey_df[DEPRESSION_PHQ8_SEVERITY_QUESTION_ID] =\
        survey_df.apply(lambda row: get_depression_severity(row), axis=1)


def add_survey_num_to_col_name(col_name, survey_num):
    if survey_num == 1 or col_name == 'sha1_hash':
        # survey 1 uses the default column names
        return col_name
    return 'S{}_{}'.format(survey_num, col_name)


def fill_missing_depression_columns(survey_df):
    # fill survey 4 columns with survey 1 columns if survey 4 is not available
    s4_diagnosis_id = add_survey_num_to_col_name(DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID, 4)
    s4_severity_id = add_survey_num_to_col_name(DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID, 4)
    survey_df[s4_diagnosis_id] = survey_df.apply(
        lambda x: x[DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID] if np.isnan(x[s4_diagnosis_id]) else x[s4_diagnosis_id],
        axis=1)
    survey_df[s4_severity_id] = survey_df.apply(
        lambda x: x[DEPRESSION_PHQ8_SEVERITY_QUESTION_ID] if np.isnan(x[s4_severity_id]) else x[s4_severity_id],
        axis=1)
