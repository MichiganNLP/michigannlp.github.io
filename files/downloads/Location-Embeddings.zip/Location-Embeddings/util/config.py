# location data
import datetime
import os

from util.enums import Semester, RepresentationLevel

NUMERICAL_TEXT_MAP = 'data/survey/num_text_map.json'

WINTER_2018_LOCATION_DATA_PATH = 'data/winter_2018_location_processed/'
FALL_2018_LOCATION_DATA_PATH = 'data/fall_2018_location_processed/'
WINTER_2019_LOCATION_DATA_PATH = 'data/winter_2019_location_processed/'

# survey data
WINTER_2018_SURVEY_1_DATA_PATH = 'data/survey/winter_2018_1.csv'
WINTER_2018_SURVEY_4_DATA_PATH = 'data/survey/winter_2018_4.csv'
FALL_2018_SURVEY_1_DATA_PATH = 'data/survey/fall_2018_1.csv'
FALL_2018_SURVEY_4_DATA_PATH = 'data/survey/fall_2018_4.csv'
WINTER_2019_SURVEY_1_DATA_PATH = 'data/survey/winter_2019_1.csv'
WINTER_2019_SURVEY_4_DATA_PATH = 'data/survey/winter_2019_4.csv'

# LARC data
WINTER_2018_LARC_DATA_PATH = 'data/LARC/winter_2018/'
FALL_2018_LARC_DATA_PATH = 'data/LARC/fall_2018/'
WINTER_2019_LARC_DATA_PATH = 'data/LARC/winter_2019/'

# LARC data indices
WINTER_2018_LARC_TERM_DT = 'WN 2018'
FALL_2018_LARC_TERM_DT = 'FA 2018'
WINTER_2019_LARC_TERM_DT = 'WN 2019'

# data by semester
WINTER_2018_DATA_PATHS = {
    'LOCATION': WINTER_2018_LOCATION_DATA_PATH,
    'SURVEY_1': WINTER_2018_SURVEY_1_DATA_PATH,
    'SURVEY_4': WINTER_2018_SURVEY_4_DATA_PATH,
    'LARC': {
        'class_term_info': os.path.join(WINTER_2018_LARC_DATA_PATH, 'stdnt_class_term_info.csv'),
        'info': os.path.join(WINTER_2018_LARC_DATA_PATH, 'stdnt_info.csv'),
        'term_info': os.path.join(WINTER_2018_LARC_DATA_PATH, 'stdnt_term_info.csv'),
        'term_transfer_info': os.path.join(WINTER_2018_LARC_DATA_PATH, 'stdnt_term_trnsfr_info.csv'),
        'mapping':  os.path.join(WINTER_2018_LARC_DATA_PATH, 'larc_mapping_winter_2018.csv')
    },
    'TEST_IDS': 'data/test_ids/winter_2018.txt',
    'TRAIN_IDS': 'data/train_ids/winter_2018.txt',
    'CV_ID_TEMPLATE': 'data/cv_ids/winter_2018_fold_{}_of_{}.txt',
}

FALL_2018_DATA_PATHS = {
    'LOCATION': FALL_2018_LOCATION_DATA_PATH,
    'SURVEY_1': FALL_2018_SURVEY_1_DATA_PATH,
    'SURVEY_4': FALL_2018_SURVEY_4_DATA_PATH,
    'LARC': {
        'class_term_info': os.path.join(FALL_2018_LARC_DATA_PATH, 'stdnt_class_term_info_deidentified_fall_2018.csv'),
        'info': os.path.join(FALL_2018_LARC_DATA_PATH, 'stdnt_info_deidentified_fall_2018.csv'),
        'term_info': os.path.join(FALL_2018_LARC_DATA_PATH, 'stdnt_term_info_deidentified_fall_2018.csv'),
        'term_transfer_info':
            os.path.join(FALL_2018_LARC_DATA_PATH, 'stdnt_term_trnsfr_info_deidentified_fall_2018.csv'),
    },
    'TEST_IDS': 'data/test_ids/fall_2018.txt',
    'TRAIN_IDS': 'data/train_ids/fall_2018.txt',
    'CV_ID_TEMPLATE': 'data/cv_ids/fall_2018_fold_{}_of_{}.txt',
}

WINTER_2019_DATA_PATHS = {
    'LOCATION': WINTER_2019_LOCATION_DATA_PATH,
    'SURVEY_1': WINTER_2019_SURVEY_1_DATA_PATH,
    'SURVEY_4': WINTER_2019_SURVEY_4_DATA_PATH,
    'LARC': {
        'class_term_info':
            os.path.join(WINTER_2019_LARC_DATA_PATH, 'stdnt_class_term_info_deidentified_winter_2019.csv'),
        'info': os.path.join(WINTER_2019_LARC_DATA_PATH, 'stdnt_info_deidentified_winter_2019.csv'),
        'term_info': os.path.join(WINTER_2019_LARC_DATA_PATH, 'stdnt_term_info_deidentified_winter_2019.csv'),
        'term_transfer_info':
            os.path.join(WINTER_2019_LARC_DATA_PATH, 'stdnt_term_trnsfr_info_deidentified_winter_2019.csv'),
    },
    'TEST_IDS': 'data/test_ids/winter_2019.txt',
    'TRAIN_IDS': 'data/train_ids/winter_2019.txt',
    'CV_ID_TEMPLATE': 'data/cv_ids/winter_2019_fold_{}_of_{}.txt',
}


LOCATION_DATES = {
    Semester.WINTER_2018: {
        'START_DATE': datetime.datetime.strptime('2017-10-01', '%Y-%m-%d'),
        'END_DATE': datetime.datetime.strptime('2018-04-29', '%Y-%m-%d')
    },
    Semester.FALL_2018: {
        'START_DATE': datetime.datetime.strptime('2018-06-01', '%Y-%m-%d'),
        'END_DATE': datetime.datetime.strptime('2018-12-31', '%Y-%m-%d')
    },
    Semester.WINTER_2019: {
        'START_DATE': datetime.datetime.strptime('2018-10-01', '%Y-%m-%d'),
        'END_DATE': datetime.datetime.strptime('2019-05-04', '%Y-%m-%d')
    }
}

# pickle directories
N_SEMESTERS = 3 if ('N_SEMESTERS' not in os.environ or int(os.environ['N_SEMESTERS']) == 3) else 2

PICKLE_BASE_DIR = 'pickled'
PICKLE_DIR_2_SEMESTERS = '{}/WN18_FA18'.format(PICKLE_BASE_DIR)
PICKLE_DIR_3_SEMESTERS = '{}/WN18_FA18_WN19'.format(PICKLE_BASE_DIR)

PICKLE_DIR = PICKLE_DIR_3_SEMESTERS if N_SEMESTERS == 3 else PICKLE_DIR_2_SEMESTERS

# default word2vec params
DEFAULT_WORD2VEC_EPOCHS = 100
DEFAULT_WORD2VEC_NEGATIVE_SAMPLING = 20
DEFAULT_WORD2VEC_VECTOR_SIZE = 25
DEFAULT_WORD2VEC_WINDOW_SIZE = 5
DEFAULT_WORD2VEC_SKIP_GRAM = True

DEFAULT_HOUR_CHUNKS = False

# question IDs
CLASS_YEAR_QUESTION_ID = 'Q2.6'
CUMULATIVE_GPA_QUESTION_ID = 'CUM_GPA'
CURRENT_GPA_QUESTION_ID = 'CURR_GPA'
UNDERGRADUATE_SCHOOL_QUESTION_ID = 'PRMRY_CRER_DES'
SLEEP_QUESTION_ID = 'Q12.2'
DEPRESSION_QUESTION_ID = 'Q8.3_2'
GENDER_QUESTION_ID = 'Q2.4'
DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID = 'DEPRESSION_PHQ8_DIAGNOSIS_TERNARY'
DEPRESSION_PHQ8_SEVERITY_QUESTION_ID = 'DEPRESSION_PHQ8_SEVERITY'

# number of hours for each representation level
N_ITEMS = {
    RepresentationLevel.DAY: 24,
    RepresentationLevel.WEEK: 7 * 24,
    RepresentationLevel.MONTH: 7 * 24 * 31
}

LOGGING_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
