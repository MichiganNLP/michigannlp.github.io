from copy import deepcopy

from util import load_test_output
from util.enums import ClassificationLevel, MetaClassifier, RepresentationLevel, VectorMethod
from util.prep_location_embeddings import get_location_embeddings, get_multiple_location_embeddings

STATIC_METHODS = [
    "One-Hot Avg",
    "Twitter",
    "Reddit",
    "Campus-Website",
    "Reddit-Retrofit",
]

SEEDED_METHODS = [
    "Loc2V",
    "Loc2V-Reddit",
]

whitelist = 'data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist'

# common arguments for all models
COMMON_ARGS = {
    "add_hr": False,
    "balance_data": False,
    "classification_level": ClassificationLevel.STUDENT,
    "class_weight": "balanced",
    "classifier_args": {"kernel": "linear"},
    "classifier_str": "SVM",
    "cross_validate_all": True,
    "cross_validate_all_n_folds": 10,
    "include_validation_fold": False,
    "meta_classifier": MetaClassifier.INDIVIDUAL_KEY_SVM,
    "normalize_student_vectors": True,
    "representation_level": RepresentationLevel.MONTH,
    "test": True,
    "validation_method": "cv",
    "vector_method": VectorMethod.WEIGHTED_AVERAGE_IGNORE_SHORT,
}  # add task, w2v_file_id


def get_results_by_file_id(file_id: str, task: str):
    args = deepcopy(COMMON_ARGS)
    args.update({"w2v_file_id": file_id, "task": task})
    return load_test_output(str(sorted(args.items())))


def get_multiple_location_embeddings_by_id(paper_id: str):
    assert paper_id in SEEDED_METHODS
    if paper_id == "Loc2V":
        return get_multiple_location_embeddings(use_whitelist=whitelist, skip_gram=True, vector_size=25, window_size=5,
                                                epochs=5, negative=20, hour_chunks=True)
    elif paper_id == "Loc2V-Reddit":
        return get_multiple_location_embeddings(use_whitelist=whitelist, text_embedding_methods=[
            'reddit_mention.tfidf_pretrained.glove_twitter'], skip_gram=True, vector_size=25, window_size=5, epochs=5,
                                                negative=20, hour_chunks=True)
    else:
        raise Exception("Unsupported paper_id")


def get_location_embeddings_by_id(paper_id: str):
    assert paper_id in STATIC_METHODS
    if paper_id == "One-Hot Avg":
        return get_location_embeddings(use_whitelist=whitelist, onehot=True, seed=243)
    elif paper_id == "Twitter":
        return get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                       text_embedding_methods=['twitter_geo.tfidf_pretrained.glove_twitter'])
    elif paper_id == "Reddit":
        return get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                       text_embedding_methods=['reddit_mention.tfidf_pretrained.glove_twitter'])
    elif paper_id == "Campus-Website":
        return get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                       text_embedding_methods=['campus_info.tfidf_pretrained.glove_twitter'])
    elif paper_id == "Reddit-Retrofit":
        return get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                       text_embedding_methods=['reddit_mention.tfidf_pretrained.glove_twitter'],
                                       retrofit_location_graph_weighted=True)
    else:
        raise Exception("Unsupported paper_id")
