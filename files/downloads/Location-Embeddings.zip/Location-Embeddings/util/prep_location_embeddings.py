import itertools
import pickle
import random
import typing
from collections import defaultdict

import gensim
import numpy as np
import pandas as pd

from features import retrofit, location_embedding
from util import util, normalize
from util.enums import TextType


def _is_glove_or_word2vec(method: str):
    """
    Checks if method (from saved file) requires training with GloVe or word2vec
    """
    return '.' not in method and ('glove' in method or 'word2vec' in method)


def _get_text_embeddings(embedding_method: str, seed: int=None):
    """
    Reads vectors based on text about places from disk. If necessary, trains embeddings.
    """
    data_source, method = embedding_method.split('.', 1)

    file_method = 'processed_text' if _is_glove_or_word2vec(embedding_method) else method

    filename = 'text_embeddings/{}/{}.pickle'.format(data_source, file_method)
    with open(filename, 'rb') as f:
        saved_data = pickle.load(f)
    # if we are not using word2vec or GloVe, we can just return the embeddings from disk
    if not _is_glove_or_word2vec(method):
        return saved_data
    # otherwise, we need to train the embedding model with a seed
    if method == 'word2vec':
        sequences = list(itertools.chain.from_iterable(saved_data.values()))
        vocab = set(saved_data.keys())
        model = gensim.models.word2vec.Word2Vec(sequences, sg=True, seed=seed)
        return util.trim_non_vocab(model, vocab)
    elif method == 'word2vec_preinitialized':
        sequences = list(saved_data.values())
        vocab = set(saved_data.keys())
        # initialize without sequences, train later
        model = gensim.models.word2vec.Word2Vec(sg=True, seed=seed, size=300)
        model.build_vocab(sequences)
        model.intersect_word2vec_format('resources/GoogleNews-vectors-negative300.bin', binary=True)
        model.train(sequences, total_examples=model.corpus_count,epochs=model.iter)
        return util.trim_non_vocab(model, vocab)
    elif method == 'glove':
        raise NotImplementedError()


def _append_additional_embeddings(model, additional_embedding_methods, seed=None, should_normalize=True):
    """
    Concatenates additional location vectors (e.g. from reddit data) to word2vec model
    """
    # load additional embeddings
    additional = defaultdict(dict)
    vector_sizes = {}
    text_embedding_vocab = set()
    for embedding_method in additional_embedding_methods:
        text_embeddings = _get_text_embeddings(embedding_method, seed=seed)
        additional[embedding_method] = text_embeddings
        if type(text_embeddings) == dict:
            vector_sizes[embedding_method] = len(next(iter(text_embeddings.values())))
            for key in text_embeddings:
                text_embedding_vocab.add(key)
        elif type(text_embeddings) == gensim.models.word2vec.Word2Vec:
            vector_sizes[embedding_method] = text_embeddings.vector_size
            text_embedding_vocab.update(text_embeddings.wv.vocab.keys())
        else:
            raise Exception('Unsupported data type')

    # get vocab - this depends on if we have a w2v model
    # w2v model will cover all buildings if it exists
    # if it does not exist, use the union of keys from each text embedding model
    vocab = model.keys() if model else text_embedding_vocab

    # concatenate embeddings to create new model
    new_model = {}
    total_vector_length = 0
    for word in vocab:
        if model:
            new_vector = util.normalize_array(model[word], should_normalize)
        else:
            new_vector = np.array([])
        for embedding_method in additional_embedding_methods:
            if word in additional[embedding_method]:
                new_vector = np.concatenate((new_vector, additional[embedding_method][word]))
            else:
                new_vector = np.concatenate((new_vector, np.zeros(vector_sizes[embedding_method])))
        new_model[word] = new_vector
        total_vector_length = len(new_vector)
    if should_normalize:
        new_model = _normalize_model(new_model, total_vector_length)
    return new_model


def _normalize_model(model: dict, vector_length: int):
    keys = sorted(model.keys())
    array = np.empty((len(keys), vector_length))
    for i, key in enumerate(keys):
        array[i] = model[key]
    normalized_array = normalize(array, axis=0)
    new_model = {}
    for i in range(len(keys)):
        new_model[keys[i]] = normalized_array[i]
    return new_model


def _train_model(skip_gram: bool, vector_size: int, window_size: int, epochs: int, negative: int, hour_chunks: bool,
                 seed: int):
    """
    Trains a word2vec model with the given args
    """
    functionality_map, _, _ = util.get_functionalities(single=True)
    builder = location_embedding.BuildingEmbeddingBuilder(functionality_map, skip_gram=skip_gram,
                                                          vector_size=vector_size, negative=negative, epochs=epochs,
                                                          window_size=window_size, hour_chunks=hour_chunks, seed=seed)

    return builder.train()


def get_multiple_location_embeddings(only_text_embeddings: bool = False, use_whitelist: str = False,
                                     onehot: bool = False, mult: bool = False, should_normalize: bool = True,
                                     text_embedding_methods: list = None, skip_gram: bool = True, vector_size: int = 25,
                                     window_size: int = 5, epochs: int = 5, negative: int = 20,
                                     hour_chunks: bool = False, retrofit_location_graph: bool = False,
                                     retrofit_location_graph_weighted: bool = False,
                                     retrofit_location_graph_iters: int = 10, multiple: int = 10):
    seeds = util.get_iteration_seeds()[:multiple]
    models = []
    file_ids = []
    for seed in seeds:
        model, file_id = get_location_embeddings(only_text_embeddings, use_whitelist, onehot, seed, mult,
                                                 should_normalize, text_embedding_methods, skip_gram, vector_size,
                                                 window_size, epochs, negative, hour_chunks, retrofit_location_graph,
                                                 retrofit_location_graph_weighted, retrofit_location_graph_iters)
        models.append(model)
        file_ids.append(file_id)
    return models, file_ids


def get_location_embeddings(only_text_embeddings: bool = False, use_whitelist: str = False, onehot: bool = False,
                            seed: int = None, mult: bool = False, should_normalize: bool = True,
                            text_embedding_methods: list = None, skip_gram: bool = True, vector_size: int = 25,
                            window_size: int = 5, epochs: int = 5, negative: int = 20, hour_chunks: bool = False,
                            retrofit_location_graph: bool = False, retrofit_location_graph_weighted: bool = False,
                            retrofit_location_graph_iters: int = 10):
    # intial embedding setup
    if only_text_embeddings:
        file_id = 'only_text'
        if mult:
            file_id = '{}_{}'.format(file_id, seed)
        model = None
    elif onehot:
        buildings = set()
        for csv_path in util.get_location_csv_paths():
            df = pd.read_csv(csv_path)
            for row in df.itertuples():
                buildings.add(row.Location)

        random.seed(seed)
        list_locations = sorted(list(buildings))
        random.shuffle(list_locations)
        building_onehot_dummies = pd.get_dummies(list_locations)
        model = {building: np.array(building_onehot_dummies[building]) for building in buildings}

        file_id = 'building_onehot_{}'.format(seed)

        with open('{}/location_vectors/{}.pickle'.format(util.config.PICKLE_DIR, file_id),
                  'wb') as pickle_file:
            pickle.dump(model, pickle_file)
    else:
        args = util.get_args_with_defaults(
            epochs=epochs, negative=negative, skip_gram=skip_gram, vector_size=vector_size, window_size=window_size,
            hour_chunks=hour_chunks)

        model, file_id = util.try_read_word2vec_model(argparse_args=args, seed=seed)
        if model is None:

            model = _train_model(skip_gram, vector_size, window_size, epochs, negative, hour_chunks, seed)
            file_id = util.save_word2vec_model(model, args, seed)

    # normalization for word2vec --> do this before concatenating with text sources
    if model is not None:
        if type(model) == gensim.models.word2vec.Word2Vec:
            model_dict = {}
            for word in model.wv.vocab:
                model_dict[word] = model.wv[word]
            size = model.vector_size
            model = model_dict
        else:
            size = len(list(model.values())[0])
        model = _normalize_model(model, size)

    # final touches
    if text_embedding_methods:
        model = _append_additional_embeddings(model, text_embedding_methods, seed=seed,
                                              should_normalize=should_normalize)
        file_id = '{}_{}'.format(file_id, '_'.join(text_embedding_methods))
    if use_whitelist:
        with open(use_whitelist, "r") as f:
            whitelist_buildings = f.read().splitlines()
        whitelist_id = use_whitelist.split("/")[-1].split(".")[0]
        new_model = {}
        for building in whitelist_buildings:
            if building in model:
                new_model[building] = model[building]
            else:
                raise Exception("All buildings in whitelist should exist in model!")
        file_id += '_whitelist_' + whitelist_id
        model = new_model
    if retrofit_location_graph:
        model = retrofit.retrofit_location_graph(model, n_iters=retrofit_location_graph_iters)
        # default to not listing iters, since previously this was just set to 10
        iters_id = '' if retrofit_location_graph_iters == 10 else '_{}_iters'.format(retrofit_location_graph_iters)
        file_id += '_retrofit_location_graph{}'.format(iters_id)
    if retrofit_location_graph_weighted:
        model = retrofit.retrofit_location_graph(model, n_iters=retrofit_location_graph_iters, use_weights=True)
        iters_id = '' if retrofit_location_graph_iters == 10 else '_{}_iters'.format(retrofit_location_graph_iters)
        file_id += '_retrofit_location_graph_weighted{}'.format(iters_id)
    if should_normalize:
        file_id += '_normalized'

    return model, file_id
