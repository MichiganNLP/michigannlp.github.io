# Building Location Embeddings from Physical Trajectories and Textual Representations
Code for AACL 2020 paper.

### Creating Embeddings
Under features/
* `location_embeddings.py`: create embeddings using w2v
* `text_vector.py`: create embeddings using text data
* `retrofit.py`: code for retrofitting, adapted from [the original code](https://github.com/mfaruqui/retrofitting/blob/master/retrofit.py)

### Evaluation
Under evaluation/
* `surface_level_probe.py`: surface level sequence tasks
* `downstream_task_evaluation.py`: downstream tasks
Under notebooks/
* `Surface_Level_Location_Tasks.ipynb`: surface level location tasks
* `Surface_Level_Probe.ipynb`: surface level sequence tasks

### Data
Our data cannot be released publicly due to privacy concerns.