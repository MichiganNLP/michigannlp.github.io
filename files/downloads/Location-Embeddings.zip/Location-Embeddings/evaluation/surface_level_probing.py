import inspect
import logging
import os
import pickle
import random
from collections import Counter, defaultdict
from functools import wraps

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sn
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import KFold
from sklearn.svm import SVC

import util
from util.build_student_vectors import get_student_vectors
from util.enums import VectorMethod, RepresentationLevel

SURFACE_LEVEL_RESULTS_DIR = 'surface_level_results_v2'

logging.basicConfig(format=util.LOGGING_FORMAT)
logger = logging.getLogger(__file__)


def _make_hash(item):
    assert ('PYTHONHASHSEED' in os.environ and os.environ['PYTHONHASHSEED'] == '0')
    try:
        return hash(item)
    except:
        return hash(str(item))


def pickle_output(func):
    """
    Got the idea for this from https://stackoverflow.com/a/45866783
    """
    # TODO: I don't think this works between different calls to prep_embeddings
    sig = inspect.signature(func)
    name = func.__name__

    @wraps(func)
    def wrapper(*args, **kwargs):
        bound_args = sig.bind(*args, **kwargs)
        pickle_filename = os.path.join(
            util.config.PICKLE_DIR, SURFACE_LEVEL_RESULTS_DIR, name,
            '{}.{}.pickle'.format(name, _make_hash(bound_args)))
        if os.path.exists(pickle_filename):
            with open(pickle_filename, 'rb') as f:
                return pickle.load(f)
        print("not loading from pickle...")
        result = func(*args, **kwargs)
        with open(pickle_filename, 'wb') as f:
            pickle.dump(result, f)
        return result

    return wrapper


def display_results(accuracy, macro_f1, gold_standard, predictions, task=''):
    print('Accuracy: {}'.format(accuracy))
    print('Macro F1: {}'.format(macro_f1))
    cm = pd.crosstab(pd.Series(gold_standard), pd.Series(predictions), rownames=['True'], colnames=['Predicted'])
    sn.heatmap(cm, annot=True, fmt='g', cmap='Blues')
    plt.title('Confusion Matrix for {} Prediction'.format(task))
    plt.show()


def train_and_test_classifier(X_train, y_train, X_test=None, y_test=None, dev=True, task='', print_results=False):
    classifier = SVC(kernel='linear', class_weight='balanced')
    if dev:
        kf = KFold(5)
        predictions = []
        y = []
        for train_fold, test_fold in kf.split(X_train, y_train):
            X_train_fold, y_train_fold = X_train[train_fold], y_train[train_fold]
            X_test_fold, y_test_fold = X_train[test_fold], y_train[test_fold]
            classifier.fit(X_train_fold, y_train_fold)
            p = classifier.predict(X_test_fold)
            predictions.extend(p)
            y.extend(y_test_fold)

        y_test = np.array(y)
    else:
        classifier.fit(X_train, y_train)
        predictions = classifier.predict(X_test)

    baseline = Counter(y_test).most_common(1)[0][1] / len(predictions)
    accuracy = accuracy_score(y_test, predictions)
    macro_f1 = f1_score(y_test, predictions, average='macro')

    if print_results:
        display_results(accuracy, macro_f1, y_test, predictions, task=task)
    return baseline, accuracy, macro_f1, predictions, y_test


def _split_data_to_folds(vector_map, sequence_map, n_folds):
    fold_id_map = util.get_folds(10)
    fold_list = []
    for i in range(n_folds):
        test_ids = set(fold_id_map[(i + 1) % 10])
        train_vector_list = [v for k, v in vector_map.items() if k not in test_ids]
        test_vector_list = [v for k, v in vector_map.items() if k in test_ids]
        train_sequence_list = [v for k, v in sequence_map.items() if k not in test_ids]
        test_sequence_list = [v for k, v in sequence_map.items() if k in test_ids]
        fold_list.append((train_vector_list, test_vector_list, train_sequence_list, test_sequence_list))
    return fold_list


def create_input_output_functionality_presence(sequence_maps, vector_maps, functionality, func_to_buildings,
                                               balance_data=False, n_instances=None):
    sequences_and_vectors = []
    for sequence_map, vector_map in zip(sequence_maps, vector_maps):
        for timestamp in vector_map:
            sequences_and_vectors.append((sequence_map[timestamp], vector_map[timestamp]))

    rnd = random.Random(10)
    true_sequences = []
    false_sequences = []
    for sequence, vector in sequences_and_vectors:
        in_sequence = False
        for building in func_to_buildings[functionality]:
            if building in sequence:
                in_sequence = True
                break
        if in_sequence:
            true_sequences.append(vector)
        else:
            false_sequences.append(vector)

    rnd.shuffle(true_sequences)
    rnd.shuffle(false_sequences)
    if n_instances:
        true_sequences = true_sequences[:n_instances]
        false_sequences = false_sequences[:n_instances]
    if balance_data:
        if len(true_sequences) > len(false_sequences):
            rnd.shuffle(true_sequences)
            true_sequences = true_sequences[:len(false_sequences)]
        elif len(false_sequences) > len(true_sequences):
            rnd.shuffle(false_sequences)
            false_sequences = false_sequences[:len(true_sequences)]
    x_y = [(sequence, False) for sequence in false_sequences] + [(sequence, True) for sequence in true_sequences]
    rnd.shuffle(x_y)
    X, y = np.array([item[0] for item in x_y]), np.array([item[1] for item in x_y])
    return X, y


def _build_functionality_whitelist(sequence_map, min_vals_per_class, building_functionality_map, functionalities):
    total_sequences = 0
    functionality_counts = Counter()
    for time_sent_dict in sequence_map.values():
        for sent in time_sent_dict.values():
            functionalities_in_sent = set()
            for building in sent:
                for fn in building_functionality_map[building]:
                    if fn in functionalities:
                        functionalities_in_sent.add(fn)
            functionality_counts.update(functionalities_in_sent)
            total_sequences += 1
    functionality_whitelist = set()
    for building, count in functionality_counts.items():
        if (count >= min_vals_per_class) and (total_sequences - count >= min_vals_per_class):
            functionality_whitelist.add(building)
    return functionality_whitelist


@pickle_output
def _functionality_presence_func_helper(X_train, y_train, test_sequence_list, test_vector_list, functionality,
                                        func_to_buildings):
    X_test, y_test = create_input_output_functionality_presence(test_sequence_list, test_vector_list, functionality,
                                                                func_to_buildings)
    _, _, _, gold_standard, predictions = train_and_test_classifier(X_train, y_train, X_test=X_test,
                                                                    y_test=y_test, dev=False)
    return gold_standard, predictions


def _functionality_presence_fold_helper(train_vector_list, test_vector_list, train_sequence_list, test_sequence_list,
                                        functionality_whitelist, func_to_buildings):
    train_data_by_functionality = {}
    for functionality in functionality_whitelist:
        X_train, y_train = create_input_output_functionality_presence(
            train_sequence_list, train_vector_list, functionality, func_to_buildings)
        train_data_by_functionality[functionality] = X_train, y_train

    gold_standard_by_func = {}
    predictions_by_func = {}
    for functionality, (X_train, y_train) in train_data_by_functionality.items():
        logger.debug(functionality)
        gold_standard, predictions = _functionality_presence_func_helper(
            X_train, y_train, test_sequence_list, test_vector_list, functionality, func_to_buildings)
        gold_standard_by_func[functionality], predictions_by_func[functionality] = gold_standard, predictions
    return predictions_by_func, gold_standard_by_func


@pickle_output
def _functionality_presence(vector_map, sequence_map, n_folds=10, print_results=True, min_vals_per_class=100):
    building_functionality_map, functionalities, buildings = util.get_functionalities()
    functionality_whitelist = _build_functionality_whitelist(
        sequence_map, min_vals_per_class, building_functionality_map, functionalities)

    func_to_buildings = defaultdict(list)
    for functionality in functionality_whitelist:
        for building_name, fns in building_functionality_map.items():
            if functionality in fns:
                func_to_buildings[functionality].append(building_name)

    fold_list = _split_data_to_folds(vector_map, sequence_map, n_folds)

    all_pred_by_func = defaultdict(list)
    all_gold_by_func = defaultdict(list)
    fold_f1s = []
    for i, (train_vector_list, test_vector_list, train_sequence_list, test_sequence_list) in enumerate(fold_list):
        logger.debug('fold: %s', i)
        pred_by_func, gs_by_func = _functionality_presence_fold_helper(
            train_vector_list, test_vector_list, train_sequence_list, test_sequence_list, functionality_whitelist,
            func_to_buildings)
        func_f1s = []
        for func in functionality_whitelist:
            all_pred_by_func[func].extend(pred_by_func[func])
            all_gold_by_func[func].extend(gs_by_func[func])
            func_f1s.append(f1_score(gs_by_func[func], pred_by_func[func], average="macro"))
        fold_f1s.append(np.mean(func_f1s))

    # now, compute accuracies/results by building across folds
    acc_by_func = {}
    f1_by_func = {}
    all_gold_standard = []
    all_predictions = []
    for func in sorted(functionality_whitelist):
        acc_by_func[func] = accuracy_score(all_gold_by_func[func], all_pred_by_func[func])
        f1_by_func[func] = f1_score(all_gold_by_func[func], all_pred_by_func[func], average='macro')
        all_gold_standard.extend(all_gold_by_func[func])
        all_predictions.extend(all_pred_by_func[func])

    # finally, average accuracies between buildings
    accuracy = np.mean(list(acc_by_func.values()))
    f1 = np.mean(list(f1_by_func.values()))

    if print_results:
        display_results(accuracy, f1, all_gold_standard, all_predictions, task='Functionality Presence')
    return accuracy, f1, all_predictions, all_gold_standard, acc_by_func, f1_by_func, fold_f1s


def functionality_presence_multiple(input_data, n_folds=10, print_results=True):
    accuracies = []
    f1s = []
    all_predictions = []
    all_gold_standard = []
    acc_list_by_func = defaultdict(list)
    f1_list_by_func = defaultdict(list)
    all_f1s = []
    for i, (vector_map, sequence_map) in enumerate(input_data):
        acc, f1, pred, gs, abf, f1bf, seed_f1s = _functionality_presence(
            vector_map, sequence_map, n_folds=n_folds, print_results=False)
        all_f1s.extend(seed_f1s)
        accuracies.append(acc)
        f1s.append(f1)
        all_predictions.extend(pred)
        all_gold_standard.extend(gs)
        for functionality in abf.keys():
            acc_list_by_func[functionality].append(abf[functionality])
            f1_list_by_func[functionality].append(f1bf[functionality])
    if print_results:
        display_results(np.mean(accuracies), np.mean(f1s), all_gold_standard, all_predictions,
                        task='Functionality Presence')
    acc_by_func = {functionality: np.mean(acc_list) for functionality, acc_list in acc_list_by_func.items()}
    f1_by_func = {functionality: np.mean(f1_list) for functionality, f1_list in f1_list_by_func.items()}
    return accuracies, f1s, all_predictions, all_gold_standard, acc_by_func, f1_by_func, all_f1s


def create_input_output_location_presence(sequence_maps, vector_maps, building, balance_data=False, n_instances=None):
    sequences_and_vectors = []
    for sequence_map, vector_map in zip(sequence_maps, vector_maps):
        for timestamp in vector_map:
            sequences_and_vectors.append((sequence_map[timestamp], vector_map[timestamp]))

    rnd = random.Random(10)
    true_sequences = []
    false_sequences = []
    for sequence, vector in sequences_and_vectors:
        if building in sequence:
            true_sequences.append(vector)
        else:
            false_sequences.append(vector)
    # balance data (a bit hacky but it does the right thing)
    rnd.shuffle(true_sequences)
    rnd.shuffle(false_sequences)
    if n_instances:
        true_sequences = true_sequences[:n_instances]
        false_sequences = false_sequences[:n_instances]
    if balance_data:
        if len(true_sequences) > len(false_sequences):
            rnd.shuffle(true_sequences)
            true_sequences = true_sequences[:len(false_sequences)]
        elif len(false_sequences) > len(true_sequences):
            rnd.shuffle(false_sequences)
            false_sequences = false_sequences[:len(true_sequences)]
    x_y = [(sequence, False) for sequence in false_sequences] + [(sequence, True) for sequence in true_sequences]
    rnd.shuffle(x_y)
    X, y = np.array([item[0] for item in x_y]), np.array([item[1] for item in x_y])
    return X, y


@pickle_output
def _location_presence_build_helper(X_train, y_train, test_sequence_list, test_vector_list, building):
    X_test, y_test = create_input_output_location_presence(test_sequence_list, test_vector_list, building)
    _, _, _, gold_standard, predictions = train_and_test_classifier(X_train, y_train, X_test=X_test,
                                                                    y_test=y_test, dev=False)
    return gold_standard, predictions


def _location_presence_fold_helper(train_vector_list, test_vector_list, train_sequence_list, test_sequence_list,
                                   location_whitelist):
    train_data_by_building = {}
    for building in location_whitelist:
        X_train, y_train = create_input_output_location_presence(train_sequence_list, train_vector_list, building)
        train_data_by_building[building] = X_train, y_train

    gold_standard_by_building = {}
    predictions_by_building = {}
    for building, (X_train, y_train) in train_data_by_building.items():
        logger.debug(building)
        gold_standard, predictions = _location_presence_build_helper(
            X_train, y_train, test_sequence_list, test_vector_list, building)
        gold_standard_by_building[building], predictions_by_building[building] = gold_standard, predictions
    return predictions_by_building, gold_standard_by_building


@pickle_output
def _location_presence(vector_map, sequence_map, n_folds=10, print_results=True, min_vals_per_class=100):
    """
    Training a binary classifier, has this person been to X building
    Or has this person been to building with X functionality
    """

    # we need to decide whether or not the test will be performed for each building outside of folds
    # otherwise the results may contain a building for some folds and not for others
    location_whitelist = _build_location_whitelist(sequence_map, min_vals_per_class)

    # these are lists of dictionaries for each building
    all_pred_by_build = defaultdict(list)
    all_gold_by_build = defaultdict(list)
    fold_list = _split_data_to_folds(vector_map, sequence_map, n_folds)
    fold_f1s = []

    for i, (train_vector_list, test_vector_list, train_sequence_list, test_sequence_list) in enumerate(fold_list):
        logger.debug('fold: %s', i)
        pred_by_build, gs_by_build = _location_presence_fold_helper(
            train_vector_list, test_vector_list, train_sequence_list, test_sequence_list, location_whitelist)
        build_f1s = []
        for build in location_whitelist:
            all_pred_by_build[build].extend(pred_by_build[build])
            all_gold_by_build[build].extend(gs_by_build[build])
            build_f1s.append(f1_score(gs_by_build[build], pred_by_build[build], average='macro'))
        fold_f1s.append(np.mean(build_f1s))

    # now, compute accuracies/results by building across folds
    acc_by_build = {}
    f1_by_build = {}
    all_gold_standard = []
    all_predictions = []
    for build in sorted(location_whitelist):
        acc_by_build[build] = accuracy_score(all_gold_by_build[build], all_pred_by_build[build])
        f1_by_build[build] = f1_score(all_gold_by_build[build], all_pred_by_build[build], average='macro')
        all_gold_standard.extend(all_gold_by_build[build])
        all_predictions.extend(all_pred_by_build[build])

    # finally, average accuracies between buildings
    accuracy = np.mean(list(acc_by_build.values()))
    f1 = np.mean(list(f1_by_build.values()))

    if print_results:
        display_results(accuracy, f1, all_gold_standard, all_predictions, task='Location Presence')
    return accuracy, f1, all_predictions, all_gold_standard, acc_by_build, f1_by_build, fold_f1s


def location_presence_multiple(input_data, n_folds=10, print_results=True):
    accuracies = []
    f1s = []
    all_predictions = []
    all_gold_standard = []
    acc_list_by_build = defaultdict(list)
    f1_list_by_build = defaultdict(list)
    all_f1s = []
    for i, (vector_map, sequence_map) in enumerate(input_data):
        if len(input_data) > 1:
            logger.debug('processing index: %s', i)
        acc, f1, pred, gs, abb, f1bb, fold_f1s = _location_presence(vector_map, sequence_map, n_folds=n_folds,
                                                                    print_results=False)
        accuracies.append(acc)
        f1s.append(f1)
        all_predictions.extend(pred)
        all_gold_standard.extend(gs)
        all_f1s.extend(fold_f1s)
        for build in abb.keys():
            acc_list_by_build[build].append(abb[build])
            f1_list_by_build[build].append(f1bb[build])
    acc_by_build = {build: np.mean(acc_list) for build, acc_list in acc_list_by_build.items()}
    f1_by_build = {build: np.mean(f1_list) for build, f1_list in f1_list_by_build.items()}
    if print_results:
        display_results(np.mean(accuracies), np.mean(f1s), all_gold_standard, all_predictions, task='Location Presence')
    return accuracies, f1s, all_predictions, all_gold_standard, acc_by_build, f1_by_build, all_f1s


def _build_location_whitelist(sequence_map, min_vals_per_class):
    total_sequences = 0
    building_counts = {}
    for time_sent_dict in sequence_map.values():
        for sent in time_sent_dict.values():
            for building in sent:
                if building not in building_counts:
                    building_counts[building] = 0
            for building in building_counts:
                if building in sent:
                    building_counts[building] += 1
            total_sequences += 1
    location_whitelist = set()
    for building, count in building_counts.items():
        if (count >= min_vals_per_class) and (total_sequences - count >= min_vals_per_class):
            location_whitelist.add(building)
    return location_whitelist


@pickle_output
def prep_embeddings(embeddings):
    sequence_map = {}
    vector_map = {}
    hashes_by_semester = util.get_hashes_by_semester(train=True, test=True)
    building_functionality_map, functionalities, buildings = util.get_functionalities()
    for semester, hashes in hashes_by_semester.items():
        semester_data_path = util.get_config(semester)['LOCATION']
        for student_hash in hashes:
            student_vectors, student_sequences = get_student_vectors(embeddings, student_hash,
                                                                     building_functionality_map,
                                                                     VectorMethod.WEIGHTED_AVERAGE_IGNORE_SHORT,
                                                                     RepresentationLevel.MONTH, semester,
                                                                     semester_data_path)
            sequence_map[student_hash] = student_sequences
            vector_map[student_hash] = student_vectors
    return vector_map, sequence_map
