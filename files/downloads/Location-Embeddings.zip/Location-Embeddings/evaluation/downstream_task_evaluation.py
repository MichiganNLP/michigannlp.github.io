import argparse
import pickle

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVR, SVC

import util
from features.map_response_to_bucket import map_to_bucket, get_bucket_mapping_fn
from models.sklearn_metaclassification_model import SKLearnMetaClassificationModel
from util import load_student_data_by_semester, get_functionalities, num_text_map, add_survey_num_to_col_name, \
    get_student_vectors
from util.config import SLEEP_QUESTION_ID, DEPRESSION_QUESTION_ID, \
    UNDERGRADUATE_SCHOOL_QUESTION_ID, GENDER_QUESTION_ID, CURRENT_GPA_QUESTION_ID, CLASS_YEAR_QUESTION_ID, \
    DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID
from util.enums import ClassificationLevel, MetaClassifier, RepresentationLevel, VectorMethod

# maps
TASK_QUESTION_MAP = {
    'sleep': SLEEP_QUESTION_ID,
    'depression': DEPRESSION_QUESTION_ID,
    'school': UNDERGRADUATE_SCHOOL_QUESTION_ID,
    'gender': GENDER_QUESTION_ID,
    'gpa': CURRENT_GPA_QUESTION_ID,
    'class_year': CLASS_YEAR_QUESTION_ID,
    'depression_phq8_major': DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID,
    'depression_phq8_all': DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID,
    'depression_phq8_all_s4': add_survey_num_to_col_name(DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID, 4),
    'depression_phq8_major_s4': add_survey_num_to_col_name(DEPRESSION_PHQ8_DIAGNOSIS_QUESTION_ID, 4),
}

CLASS_YEAR_TO_NUM = {
    'Freshman': 0,
    'Sophomore': 1,
    'Junior': 2,
    'Senior': 3,
    'Other:': 4
}


class DownstreamTaskEvaluator:
    BLACKLIST_STR_CONVERSION = {'classification_model', 'embeddings', 'run_experiment', 'rerun_experiment'}

    def __init__(self, word2vec_model, task, balance_data=True, w2v_file_id=None, test=False, classifier='svm',
                 classifier_args=None, vector_method=VectorMethod.WEIGHTED_AVERAGE_IGNORE_SHORT,
                 classification_level=ClassificationLevel.STUDENT, meta_classifier=MetaClassifier.INDIVIDUAL_KEY_SVM,
                 representation_level=RepresentationLevel.STUDENT, validation_method='cv', rerun_experiment=False,
                 balance_class_weight=False, cross_validate_all=False, cross_validate_all_n_folds=10,
                 include_validation_fold=False, normalize_student_vectors=True):
        assert(w2v_file_id is not None)

        self.embeddings = word2vec_model
        self.task = task
        self.balance_data = balance_data
        self.w2v_file_id = w2v_file_id
        self.test = test
        self.classifier_str = classifier
        self.classifier_args = classifier_args
        self.vector_method = vector_method
        self.classification_level = classification_level
        self.meta_classifier = meta_classifier
        self.representation_level = representation_level
        self.validation_method = validation_method
        self.class_weight = "balanced" if balance_class_weight else None
        self.cross_validate_all = cross_validate_all
        self.cross_validate_all_n_folds = cross_validate_all_n_folds
        self.include_validation_fold = include_validation_fold
        self.normalize_student_vectors = normalize_student_vectors
        self.rerun_experiment = rerun_experiment

        # create classifier
        self.classification_model = self._get_model()

        # check if we need to run experiment or just load previous results
        self.run_experiment = rerun_experiment or not util.test_output_exists(str(self))

    ##### MAIN FUNCTIONS TO VALIDATE/TESTS ON DOWNSTREAM TASK ##########################################################

    def evaluate(self):
        if not self.run_experiment:
            unlabeled_predictions, unlabeled_outputs, _, _ = util.load_test_output(str(self))
            accuracy, f_score, baseline, class_accuracies =\
                SKLearnMetaClassificationModel.get_and_print_classification_stats(unlabeled_predictions,
                                                                                  unlabeled_outputs)
            return accuracy, f_score, class_accuracies

        if self.cross_validate_all:
            return self._cross_validate()
        if self.test:
            accuracy, f_score = self._test_by_semesters()
            return accuracy, f_score
        return self._validate_by_semesters()

    def _cross_validate(self):
        hashes_by_semester = util.get_hashes_by_semester(train=True, test=True)

        student_vector_map, student_outputs = self.create_input_output(hashes_by_semester, w2v_file_id=self.w2v_file_id)
        classifier = SKLearnMetaClassificationModel(self.classification_model, task=self.task,
                                                    classification_level=self.classification_level,
                                                    meta_classifier=self.meta_classifier,
                                                    dte_instance_str=str(self),
                                                    class_weight=self.class_weight,
                                                    embeddings=self.embeddings)
        accuracy, f_score, baseline, class_accuracies = classifier.cv_all(
            student_vector_map, student_outputs, self, include_validation_fold=self.include_validation_fold,
            n_folds=self.cross_validate_all_n_folds)
        return accuracy, f_score, class_accuracies

    def _validate_by_semesters(self):
        hashes_by_semester = util.get_hashes_by_semester(train=True)

        student_vector_map, student_outputs = self.create_input_output(hashes_by_semester, w2v_file_id=self.w2v_file_id)
        classifier = SKLearnMetaClassificationModel(self.classification_model, task=self.task,
                                                    classification_level=self.classification_level,
                                                    meta_classifier=self.meta_classifier,
                                                    dte_instance_str=str(self),
                                                    class_weight=self.class_weight,
                                                    embeddings=self.embeddings)

        if self.validation_method == 'cv':
            accuracy, f_score, baseline, class_accuracies = classifier.cv(student_vector_map, student_outputs, folds=5)
        else:
            train_ids, validation_ids = train_test_split(sorted(list(student_vector_map.keys())), test_size=.2,
                                                         random_state=10)
            train_vector_map = {k: v for k, v in student_vector_map.items() if k in train_ids}
            validation_vector_map = {k: v for k, v in student_vector_map.items() if k in validation_ids}
            train_outputs = {k: v for k, v in student_outputs.items() if k in train_ids}
            validation_outputs = {k: v for k, v in student_outputs.items() if k in validation_ids}
            classifier.train(train_vector_map, train_outputs)
            accuracy, f_score, class_accuracies, _, _ = classifier.test(validation_vector_map, validation_outputs)

        return accuracy, f_score, class_accuracies

    def _test_by_semesters(self):
        hashes_by_semester = util.get_hashes_by_semester(train=True)
        student_vector_map_train, student_outputs_train = self.create_input_output(hashes_by_semester,
                                                                                   w2v_file_id=self.w2v_file_id)
        hashes_by_semester_test = util.get_hashes_by_semester(test=True)

        student_vector_map_test, student_outputs_test = self.create_input_output(hashes_by_semester_test)
        # sanity check that the train and test hashes are disjoint
        for semester_hashes in hashes_by_semester.values():
            for train_hash in semester_hashes:
                for test_semester_hashes in hashes_by_semester_test.values():
                    assert (train_hash not in test_semester_hashes)
        ######

        classifier = SKLearnMetaClassificationModel(self.classification_model, detailed_output=True, task=self.task,
                                                    classification_level=self.classification_level,
                                                    meta_classifier=self.meta_classifier,
                                                    dte_instance_str=str(self), embeddings=self.embeddings)
        classifier.train(student_vector_map_train, student_outputs_train)
        accuracy, f_score, _, _, _ = classifier.test(student_vector_map_test, student_outputs_test)
        return accuracy, f_score

    ##### MAIN FUNCTIONS TO VALIDATE/TESTS ON DOWNSTREAM TASK ##########################################################

    ##### ML INPUT CREATION FUNCTIONS ##################################################################################

    def create_input_output(self, hashes_by_semester, w2v_file_id=None):
        use_additional_surveys = '_s4' in self.task

        building_functionality_map, functionalities, _ = get_functionalities()
        student_vector_map, _ = util.try_read_student_embeddings(w2v_file_id, self.vector_method,
                                                                 self.representation_level,
                                                                 self.normalize_student_vectors)
        if student_vector_map is None:
            student_vector_map = {}
            for semester, hashes in hashes_by_semester.items():
                student_data = load_student_data_by_semester(semester, hashes,
                                                             additional_surveys=use_additional_surveys)
                for student_hash in student_data['sha1_hash']:
                    student_vectors, _ = get_student_vectors(self.embeddings, student_hash, building_functionality_map,
                                                             self.vector_method, self.representation_level, semester,
                                                             util.get_config(semester)['LOCATION'],
                                                             normalize=self.normalize_student_vectors)
                    student_vector_map[student_hash] = student_vectors
            if w2v_file_id is not None:
                util.save_student_embeddings((student_vector_map, None), w2v_file_id, self.vector_method,
                                             self.representation_level)

        # just re-compute outputs after balancing the data, it's fast...
        all_student_data = []
        for semester, hashes in hashes_by_semester.items():
            all_student_data.append(load_student_data_by_semester(semester, hashes,
                                                                  additional_surveys=use_additional_surveys))
        student_data = pd.concat(all_student_data, ignore_index=True, sort=True)

        student_outputs = {}

        # now work on balancing the data, after saving/loading...
        balanced_data = self._filter_and_balance_dataset(student_data)

        allowed_ids = set(balanced_data['sha1_hash'])
        student_vector_map = {k: v for k, v in student_vector_map.items() if k in allowed_ids}

        student_vector_map_allowed = {}
        for student_hash in student_vector_map.keys():
            response = student_data[student_data.sha1_hash == student_hash][TASK_QUESTION_MAP[self.task]].values[0]
            if type(response) == float and np.isnan(response):
                raise Exception('Question response should not be NaN')
            output = map_to_bucket(self.task, response)
            if output is not None:
                student_outputs[student_hash] = output
                student_vector_map_allowed[student_hash] = student_vector_map[student_hash]

        return student_vector_map_allowed, student_outputs

    def _filter_and_balance_dataset(self, student_data):
        reduction_function = None
        inclusion_function = None
        if self.task == 'depression' or self.task == 'sleep' or 'gpa' in self.task or 'depression' in self.task:
            reduction_function = get_bucket_mapping_fn(self.task)
        if self.task == 'class_year':
            inclusion_function = (lambda x: num_text_map[TASK_QUESTION_MAP[self.task]].get(str(x), None) in
                                            ['Freshman', 'Sophomore', 'Junior', 'Senior'])
        if self.task == 'gender':
            # unfortunately there is not enough data to perform classification outside of female/male
            inclusion_function = (
                lambda x: num_text_map[TASK_QUESTION_MAP[self.task]].get(str(x), None) in ['Female', 'Male'])
        if self.task == 'school':
            # a little bit unclear which schools should be including - this list has all with > 10 datapoints
            inclusion_function = (lambda x: x in ['Undergraduate L S & A', 'Undergraduate Engineering',
                                                  'Undergraduate Business Admin'])

        return util.filter_and_balance_dataset(
            student_data, TASK_QUESTION_MAP[self.task], reduction_function=reduction_function,
            inclusion_function=inclusion_function, inclusion_only=(not self.balance_data),
            filter_none=("gap" in self.task))

    ##### ML INPUT CREATION FUNCTIONS ##################################################################################

    ##### MISCELLANEOUS UTILITY FUNCTIONS ##############################################################################


    def _get_model(self):
        if self.classifier_str == 'SVR':
            return SVR(kernel=self.classifier_args['kernel'])
        elif self.classifier_str == 'SVM':
            return SVC(kernel=self.classifier_args['kernel'], class_weight=self.class_weight)
        elif self.classifier_str == 'NaiveBayes':
            return GaussianNB()

    ##### MISCELLANEOUS UTILITY FUNCTIONS ##############################################################################

    ##### OVERRIDES ####################################################################################################
    def __str__(self):
        valid_dict = {k: v for k, v in self.__dict__.items() if k not in self.BLACKLIST_STR_CONVERSION}
        add_on = "_new_run" if self.rerun_experiment else ""
        return str(sorted(valid_dict.items())) + add_on
    ##### OVERRIDES ####################################################################################################

def _get_file_id_embedding_path(embedding_path):
    return embedding_path.split('/')[-1].split('.')[0]


def _parse_args():
    parser = argparse.ArgumentParser(description="Build embeddings of buildings using student's location data")
    parser.add_argument('--embeddings_path', type=str, required=False,
                        help='Path to file containing embeddings for each building')
    parser.add_argument('--task', type=str, required=True, choices=TASK_QUESTION_MAP.keys(),
                        help='The downstream task to perform')
    parser.add_argument('--classifier', type=str, required=True,
                        choices=['SVR', 'SVM', 'NaiveBayes'],
                        help='The model to use for classification/regression')
    parser.add_argument('--kernel', type=str, choices=['linear', 'rbf'],
                        help='Kernel to use for SVM or SVR')
    parser.add_argument('--vector_method', type=VectorMethod.from_string, choices=VectorMethod,
                        default='weighted_average_term_only')
    parser.add_argument('--onehot', type=str, choices=['buildings', 'functionalities'])
    parser.add_argument('--balance_data', action='store_true')
    parser.add_argument('--representation_level', type=RepresentationLevel.from_string, required=True,
                        choices=RepresentationLevel, help='The level at which to represent training data')
    parser.add_argument('--test', action='store_true', help='Run on test data (not dev)')
    parser.add_argument('--validation_method', type=str, choices=['test', 'cv'], default='cv',
                        help='Use cross-validation or single withheld validation set for validation')
    parser.add_argument('--classification_level', choices=ClassificationLevel, type=ClassificationLevel.from_string,
                        default=ClassificationLevel.STUDENT, help='Should the classification be performed at the level '
                                                                  'of the student, or the chunk used in the '
                                                                  'representation level (i.e. week)?')
    parser.add_argument('--meta_classifier', choices=MetaClassifier, type=MetaClassifier.from_string,
                        default=MetaClassifier.INDIVIDUAL_KEY_SVM,
                        help='The way to represent meta-classification input')
    parser.add_argument('--balance_class_weight', action='store_true', help='Use class_weight="balanced" with SKLearn')
    parser.add_argument('--cross_validate_all', action='store_true', help='Do cross validation for both dev and test')
    parser.add_argument('--cross_validate_all_n_folds', type=int, default=10,
                        help='Number of folds to use when doing complete cross validation')
    parser.add_argument('--include_validation_fold', action='store_true', default=False)
    parser.add_argument('--no_normalize_student_vectors', action='store_true', default=False)

    args = parser.parse_args()
    # extra requirements for parsing
    if args.classifier in ['SVM', 'SVR'] and args.kernel is None:
        parser.error('SVM and SVR require that a kernel is specified')
    elif args.classifier not in ['SVM', 'SVR'] and args.kernel is not None:
        parser.error('kernel should not be specified if not using SVM or SVR')
    elif args.classifier not in ['SVM', 'SVR'] and args.balance_class_weight:
        parser.error('balance_class_weight should only be used with SVM or SVR')
    elif args.embeddings_path is None and not args.onehot:
        parser.error('Must specify an embeddings path or use onehot vectors')
    elif args.embeddings_path is not None and args.onehot:
        parser.error('Cannot specify an embeddings path and use onehot vectors')
    if (args.cross_validate_all and not args.test and not args.include_validation_fold):
        parser.error('When doing CV, must either be running test or include the validation fold')

    return args


def main():
    args = _parse_args()
    trained_embeddings = pickle.load(open(args.embeddings_path, 'rb'))
    classifier_args = {'kernel': args.kernel}
    dte = DownstreamTaskEvaluator(trained_embeddings, args.task, balance_data=args.balance_data,
                                  w2v_file_id=_get_file_id_embedding_path(args.embeddings_path), test=args.test,
                                  classifier=args.classifier, classifier_args=classifier_args,
                                  vector_method=args.vector_method, classification_level=args.classification_level,
                                  meta_classifier=args.meta_classifier, representation_level=args.representation_level,
                                  validation_method=args.validation_method,
                                  balance_class_weight=args.balance_class_weight,
                                  cross_validate_all=args.cross_validate_all,
                                  cross_validate_all_n_folds=args.cross_validate_all_n_folds,
                                  include_validation_fold=args.include_validation_fold,
                                  normalize_student_vectors=(not args.no_normalize_student_vectors))
    accuracy, f_score, _ = dte.evaluate()
    print('Accuracy: {}, F Score: {}'.format(accuracy, f_score))


if __name__ == '__main__':
    main()
