import argparse
import datetime
import sys
from collections import Counter

import numpy as np

import util
from evaluation import downstream_task_evaluation as dte
from util.enums import RepresentationLevel, ClassificationLevel, MetaClassifier, VectorMethod
from util.prep_location_embeddings import get_location_embeddings

DEPRESSION = 'Depression Prediction'
CLASS = 'Class Year Prediction'
GENDER = 'Gender Prediction'
SCHOOL = 'School Prediction'
SLEEP = 'Sleep Prediction'
GPA = 'GPA Prediction'
DEPRESSION_PHQ8_MAJOR = 'Major PHQ8 Prediction'
DEPRESSION_PHQ8_ALL = 'All PHQ8 Prediction'

TASK_LABEL_NAME_MAP = {
    'depression': 'Depression Prediction',
    'class_year': 'Class Year Prediction',
    'gender': 'Gender Prediction',
    'school': 'School Prediction',
    'sleep': 'Sleep Prediction',
    'gpa': 'GPA Prediction (current)',
    'depression_phq8_major': 'Major PHQ8 Prediction',
    'depression_phq8_all': 'All PHQ8 Prediction',
    'depression_phq8_all_s4': 'All PHQ8 Survey 4 Prediction',
    'depression_phq8_major_s4': 'Major PHQ8 Survey 4 Prediction',
    'gpa_cum': 'gpa_cum',
}


# These are buildings that we have representations of with every method
WHITELIST_BUILDINGS = {'WHALL', 'EHALL', 'MLB', 'TISCH', 'BEYSTER', 'GFL', 'NCCOMM', 'CHEM', 'LLOYD', 'ROSS', 'DOW',
                       'ANGL', 'KRAUS', 'PALMER', 'RNDL', 'TAPPAN', 'LORCH', 'ARTARC', 'USB', 'IOE', 'SPH2', 'NAME',
                       'BURTON', 'DANA', 'MASON', 'EQUAD', 'SPH1', 'DANCE', 'SRB', 'DC', 'LSA', 'CHRY', 'CCLTL', 'SEB',
                       'WEILL', 'CCRB', 'FXB', 'MUSEUM', 'GGBL', 'DENT', 'HAVEN', 'WALG', 'SSW', 'LBME', 'COUZ', 'MOJO',
                       'NQUAD', 'POWER', 'WEISER'}


def evaluate(model, representation_level=RepresentationLevel.STUDENT, w2v_file_id=None, test=False,
             classifier='svm', kernel='linear', classification_level=ClassificationLevel.STUDENT,
             meta_classifier=MetaClassifier.INDIVIDUAL_KEY_SVM, validation_method='cv',
             balance_data=False, tasks=None, vector_method=VectorMethod.WEIGHTED_AVERAGE_IGNORE_SHORT,
             balance_class_weight=False, cross_validate_all=False, cross_validate_all_n_folds=10):
    """
    Evaluates a model using downstream tasks
    """
    result_map = {}

    for task, task_name in TASK_LABEL_NAME_MAP.items():
        if tasks is None or task in tasks:
            evaluator = dte.DownstreamTaskEvaluator(model, task, balance_data=balance_data, w2v_file_id=w2v_file_id,
                                                    test=test, classifier=classifier,
                                                    classifier_args={'kernel': kernel}, vector_method=vector_method,
                                                    classification_level=classification_level,
                                                    meta_classifier=meta_classifier,
                                                    representation_level=representation_level,
                                                    validation_method=validation_method,
                                                    balance_class_weight=balance_class_weight,
                                                    cross_validate_all=cross_validate_all,
                                                    cross_validate_all_n_folds=cross_validate_all_n_folds)
            result_map[task_name] = evaluator.evaluate()
            sys.stdout.flush()

    return result_map


def _main_helper(args, representation_level=RepresentationLevel.STUDENT, validation_method='cv'):
    print(args, datetime.datetime.now(), 'Representation level:', representation_level)
    should_normalize = not args.no_normalize_building_vectors
    evaluation = {}
    multiple = 10 if args.mult else 1
    seeds = util.get_iteration_seeds()[:multiple]
    results = []
    for seed in seeds:
        model, file_id = get_location_embeddings(args.only_text_embeddings, args.use_whitelist, args.onehot, seed,
                                                 args.mult, should_normalize, args.text_embedding_methods,
                                                 args.skip_gram, args.vector_size, args.window_size, args.epochs,
                                                 args.negative, args.hour_chunks, args.retrofit_location_graph,
                                                 args.retrofit_location_graph_weighted,
                                                 args.retrofit_location_graph_iters)


        # evaluate embedding method
        results.append(evaluate(model, representation_level=representation_level, w2v_file_id=file_id,
                                classifier=args.classifier, kernel=args.kernel,
                                classification_level=args.classification_level,
                                meta_classifier=args.meta_classifier, validation_method=validation_method,
                                balance_data=args.balance_data, tasks=args.tasks,
                                vector_method=args.vector_method,
                                balance_class_weight=args.balance_class_weight, test=args.test,
                                cross_validate_all=args.cross_validate_all,
                                cross_validate_all_n_folds=args.cross_validate_all_n_folds))

    for key in results[0]:
        avg_dict = Counter()
        for result in results:
            for class_key, avg in result[key][2].items():
                avg_dict[class_key] += (avg / len(results))

        # only report F1
        evaluation[key] = str(np.mean([result[key][1] for result in results]))
        if args.per_class_output:
            evaluation[key] += ',' + str(avg_dict)
    # print out results in CSV-friendly format
    print(','.join(evaluation.keys()))
    print(','.join(evaluation.values()))


def _parse_args():
    parser = argparse.ArgumentParser(description='Test embeddings of buildings created with various settings')
    # word2vec params
    parser.add_argument('--skip_gram', action='store_true', default=False)
    parser.add_argument('--vector_size', type=int, default=25)
    parser.add_argument('--window_size', type=int, default=5)
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--negative', type=int, default=20)

    # additional params
    parser.add_argument('--hour_chunks', action='store_true', default=False,
                        help='Build vectors with each hour of the 24-hour day')
    parser.add_argument('--mult', action='store_true', default=False,
                        help='Run training/eval 10 times and average')
    parser.add_argument('--representation_level', required=True, choices=RepresentationLevel,
                        type=RepresentationLevel.from_string, help='The level at which to represent training data')
    parser.add_argument('--test', action='store_true', default=False,
                        help='Use test data')
    parser.add_argument('--seed', type=int, default=884, help='Random seed to be used when running on test data')
    parser.add_argument('--onehot', action='store_true', help='Use one-hot vectors instead of word2vec (baseline)')
    parser.add_argument('--classifier', type=str, required=True, choices=['SVR', 'SVM', 'NaiveBayes'],
                        help='The model to use for classification/regression')
    parser.add_argument('--kernel', type=str, choices=['linear', 'rbf'],
                        help='Kernel to use for SVM or SVR')
    parser.add_argument('--only_text_embeddings', action='store_true', required=False)
    parser.add_argument('--text_embedding_methods', nargs='+', required=False)
    parser.add_argument('--use_whitelist', type=str, default=None,
                        help='Use a whitelist of buildings that are common between methods.'
                             'Argument is path to whitelist.')
    parser.add_argument('--classification_level', choices=ClassificationLevel, type=ClassificationLevel.from_string,
                        default=ClassificationLevel.STUDENT, help='Should the classification be performed at the level '
                                                                  'of the student, or the chunk used in the '
                                                                  'representation level (i.e. week)?')
    parser.add_argument('--meta_classifier', choices=MetaClassifier, type=MetaClassifier.from_string,
                        default=MetaClassifier.INDIVIDUAL_KEY_SVM,
                        help='The way to represent meta-classification input')
    parser.add_argument('--validation_method', type=str, choices=['test', 'cv'], default='cv',
                        help='Use cross-validation or single withheld validation set for validation')
    parser.add_argument('--balance_data', action='store_true')
    parser.add_argument('--tasks', choices=TASK_LABEL_NAME_MAP.keys(), type=str, nargs='*')
    parser.add_argument('--per_class_output', action='store_true', default=False)
    parser.add_argument('--vector_method', type=VectorMethod.from_string, choices=VectorMethod,
                        default='weighted_average')
    parser.add_argument('--balance_class_weight', action='store_true', help='Use class_weight="balanced" with SKLearn')
    parser.add_argument('--cross_validate_all', action='store_true', help='Do cross validation for both dev and test')
    parser.add_argument('--cross_validate_all_n_folds', type=int, default=10,
                        help='Number of folds to use when doing complete cross validation')
    parser.add_argument('--no_normalize_building_vectors', action='store_true', default=False,
                        help='Do not normalize building vectors')
    parser.add_argument('--retrofit_location_graph', action='store_true', default=False,
                        help='Use retrofitting to add location movement data to embeddings')
    parser.add_argument('--retrofit_location_graph_weighted', action='store_true', default=False,
                        help='Use retrofitting to add weighted location movement data to embeddings')
    parser.add_argument('--retrofit_location_graph_iters', type=int, default=10,
                        help='Number of iters for retrofitting')

    args = parser.parse_args()

    if args.classifier not in ['SVM', 'SVR'] and args.kernel is not None:
        parser.error('kernel should not be specified if not using SVM or SVR')
    elif args.retrofit_location_graph and not args.only_text_embeddings:
        parser.error('can only use location graph retrofit with text embeddings')
    if args.retrofit_location_graph and args.retrofit_location_graph_weighted:
        parser.error('must choose between weighted and UW retrofitting')

    return args


def main():
    print('running main with meta-classifier...')
    args = _parse_args()
    _main_helper(args, representation_level=args.representation_level, validation_method=args.validation_method)


if __name__ == '__main__':
    main()

