import argparse
import datetime
import glob
import os
import re

import pandas as pd

from util.enums import Semester

INPUT_OUTPUT_MAP = {
    Semester.WINTER_2018: ('data/winter_2018_location/', 'data/winter_2018_location_processed/'),
    Semester.FALL_2018: ('data/fall_2018_location/', 'data/fall_2018_location_processed/'),
    Semester.WINTER_2019: ('data/winter_2019_location/', 'data/winter_2019_location_processed/'),
}


MERGE_DIFFERENCE_MINUTES = 30
TIMEOUT_HOURS = 2
MIN_CONNECTION_MINUTES = 5


def process(input_dir, output_dir):
    file_list = glob.glob(input_dir + '/*.csv')
    file_list.sort()
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    ap_dict = get_ap_dict()
    for file in file_list:
        df = pd.read_csv(file)
        print('Processing Files', file)
        if len(df) == 0:
            continue
        df = add_location(df, ap_dict)
        connections = extract_connections(df)
        trail = merge_connections(connections)

        stud_id = re.match('.*/([A-z0-9]*).csv', file).group(1)
        stud_output_dir = os.path.join(output_dir, stud_id)
        if not os.path.exists(stud_output_dir):
            os.mkdir(stud_output_dir)
        connections.to_csv(os.path.join(stud_output_dir, 'connections.csv'), encoding='utf-8')
        trail.to_csv(os.path.join(stud_output_dir, 'trail.csv'), encoding='utf-8')


def merge_connections(df):
    merged_lst = []
    for row in df.itertuples():
        if len(merged_lst) > 0 and (merged_lst[-1][1] == row.Location) \
                and (row.Start - merged_lst[-1][2]) < datetime.timedelta(minutes=MERGE_DIFFERENCE_MINUTES):
            # merge connections if they have the same location and the previous connection is less than 30 minutes from
            # the current connection
            new_duration = row.End - (merged_lst[-1][2] - datetime.timedelta(seconds=merged_lst[-1][3]))
            merged_lst[-1][3] = new_duration.total_seconds()
            merged_lst[-1][2] = row.End
        else:
            merged_lst.append(
                [row.Start.strftime('%m-%d'), row.Location, row.End, (row.End - row.Start).total_seconds()])

    # want date, location, stop time, duration

    return pd.DataFrame(merged_lst, columns=['Date', 'Location', 'Stop Time', 'Duration'])


def extract_connections(df):
    df = df.sort_values('Update Time', ascending=True).reset_index(drop=True)
    connections_lst = []

    start_time_col = _get_col_index(df, 'Start Time')
    update_time_col = _get_col_index(df, 'Update Time')
    stop_time_col = _get_col_index(df, 'Stop Time')
    location_col = _get_col_index(df, 'Location')

    curr_location = None
    curr_start = None
    curr_end = None
    for row in df.itertuples():
        if pd.isna(row[start_time_col]) or pd.notna(row[stop_time_col]) or row[location_col] == 'external':
            # do not consider rows that only have an update time
            # also do not consider rows with no valid location
            continue
        elif row[location_col] == curr_location:
            new_end = datetime.datetime.strptime(row[update_time_col], '%Y-%m-%d %H:%M:%S')
            if curr_end is not None and (new_end - curr_end) > datetime.timedelta(hours=TIMEOUT_HOURS):
                # if there is more than a two hour gap, assume that the student has likely left
                connections_lst.append((curr_location, curr_start, curr_end))
                curr_start = new_end
                curr_end = None
            else:
                curr_end = new_end
        else:
            # in this case, the location has changed. we must record this connection, then start a new connection for
            # the new location
            # we only want to create a new connection if the location has had at least two updates -> so curr_start
            # and curr_end must be DIFFERENT
            if curr_location is not None and curr_end is not None and \
                    (curr_end - curr_start) > datetime.timedelta(minutes=MIN_CONNECTION_MINUTES):
                connections_lst.append((curr_location, curr_start, curr_end))

            # not record the new location
            curr_location = row[location_col]
            curr_start = datetime.datetime.strptime(row[update_time_col], '%Y-%m-%d %H:%M:%S')
            curr_end = None

    return pd.DataFrame(connections_lst, columns=['Location', 'Start', 'End'])


def add_location(df, ap_dict):
    """
    Add location column to each entry
    """
    df['Location'] = df.apply(lambda row: ap_dict.get(row['AP Name'], 'external'), axis=1)
    return df


def get_ap_dict():
    ap_dict = {}
    ap_df = pd.read_csv('data/ap_building.csv')
    for row in ap_df[['apName', 'building']].itertuples():
        if row.apName not in ap_dict:
            ap_dict[row.apName] = row.building
    return ap_dict


def _get_col_index(df, col_name):
    return list(df.columns).index(col_name) + 1


def _parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--semester', choices=Semester, type=Semester.from_string, required=True,
                        help='Semester to process location data for')
    return parser.parse_args()


def main():
    args = _parse_args()
    input_dir, output_dir = INPUT_OUTPUT_MAP[args.semester]
    process(input_dir, output_dir)


if __name__ == '__main__':
    main()
