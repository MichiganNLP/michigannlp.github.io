import argparse
import os

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, KFold

import util
from util import Semester

NUM_TEST_PER_SEMESTER = 50
RANDOM_STATE = 10


def get_all_ids(semester, require_location=True):
    data_paths = util.get_config(semester)
    survey = pd.read_csv(data_paths['SURVEY_1'])
    survey_ids = set(survey['sha1_hash'].values)

    if not require_location:
        return survey_ids

    location_ids = set(os.listdir(data_paths['LOCATION']))

    all_ids = survey_ids.intersection(location_ids)

    print('Count\nSurvey IDs: {}\nLocation IDs: {}\nAll IDs: {}'.format(
        len(survey_ids), len(location_ids), len(all_ids)))

    return all_ids


def _generate_train_test_split(semester, all_ids):
    data_paths = util.get_config(semester)
    if os.path.exists(data_paths['TRAIN_IDS']):
        print('Have already generated split for semester {}'.format(semester))
    train, test = train_test_split(list(all_ids), test_size=NUM_TEST_PER_SEMESTER, random_state=RANDOM_STATE)

    # DO NOT OVERWRITE EXISTING train/test split files!!!
    _write_ids(data_paths['TRAIN_IDS'], train)
    _write_ids(data_paths['TEST_IDS'], test)


def _generate_folds(semester, all_ids, n_folds):
    cv_template = util.get_config(semester)['CV_ID_TEMPLATE']
    all_ids_arr = np.array(sorted(all_ids))
    kf = KFold(n_folds, shuffle=True, random_state=RANDOM_STATE)

    sanity_check = []
    for fold_id, (train_fold, test_fold) in enumerate(kf.split(all_ids_arr)):
        filename = cv_template.format(fold_id, n_folds)
        fold_ids = all_ids_arr[test_fold]
        _write_ids(filename, fold_ids)
        sanity_check.extend(fold_ids)
    assert (len(sanity_check) == len(set(sanity_check)) == len(all_ids))


def _write_ids(file_path, ids):
    if not os.path.exists(file_path):
        with open(file_path, 'w') as f:
            f.writelines('{}\n'.format(line) for line in ids)
    else:
        print('Warning: {} already exists'.format(file_path))


def _parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cv', action='store_true', default=False, help='Use CV? (default is just train/test)')
    parser.add_argument('--n_folds', type=int, default=10, help='The number of folds to use for CV')
    return parser.parse_args()


def main():
    winter_2018_ids = get_all_ids(Semester.WINTER_2018)
    fall_2018_ids = get_all_ids(Semester.FALL_2018)
    winter_2019_ids = get_all_ids(Semester.WINTER_2019)
    # we will count our intersect IDs as fall IDs, because we have less of them
    # a flaw in data collection allowed ~10 students to be in both Winter 2018 and Fall 2018 groups, but we only count
    # them once
    winter_2018_ids -= fall_2018_ids

    # other sets should not have overlap
    assert(len(winter_2019_ids.intersection(winter_2018_ids)) == 0
           and len(winter_2019_ids.intersection(fall_2018_ids)) == 0)

    # do actual splitting
    args = _parse_args()
    if args.cv:
        _generate_folds(Semester.WINTER_2018, winter_2018_ids, args.n_folds)
        _generate_folds(Semester.FALL_2018, fall_2018_ids, args.n_folds)
        _generate_folds(Semester.WINTER_2019, winter_2019_ids, args.n_folds)
    else:
        _generate_train_test_split(Semester.WINTER_2018, winter_2018_ids)
        _generate_train_test_split(Semester.FALL_2018, fall_2018_ids)
        _generate_train_test_split(Semester.WINTER_2019, winter_2019_ids)


if __name__ == '__main__':
    main()
