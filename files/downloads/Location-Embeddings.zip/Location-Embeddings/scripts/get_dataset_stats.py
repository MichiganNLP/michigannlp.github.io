import datetime
from collections import Counter

import pandas as pd

import util
from util.config import Semester


def helper(semester):
    days = 0
    n_buildings = 0
    for csv_file in util.get_location_csv_paths(semester=semester):
        df = pd.read_csv(csv_file)
        visits_per_day = Counter()
        for _, row in df.iterrows():
            stop_time = datetime.datetime.strptime(row['Stop Time'], '%Y-%m-%d %H:%M:%S')
            time_spent = datetime.timedelta(seconds=row['Duration'])
            start_day = (stop_time - time_spent).timetuple().tm_yday
            stop_day = stop_time.timetuple().tm_yday
            if start_day != stop_day:
                visits_per_day[start_day] += 1
            visits_per_day[stop_day] += 1
        days += len(visits_per_day)
        n_buildings += sum(visits_per_day.values())
    return n_buildings, days


def get_n_locations_total():
    total = 0
    for semester in Semester:
        for csv_file in util.get_location_csv_paths(semester=semester):
            df = pd.read_csv(csv_file)
            total += len(df)
    return total


def main():
    sum_winter, n_winter = helper(Semester.WINTER_2018)
    sum_fall, n_fall = helper(Semester.FALL_2018)
    sum_winter_2019, n_winter_2019 = helper(Semester.WINTER_2019)

    print('N locations per day')
    print('Winter 2018: {}'.format(sum_winter / n_winter))
    print('Fall 2018:   {}'.format(sum_fall / n_fall))
    print('Winter 2019: {}'.format(sum_winter_2019 / n_winter_2019))

    print('AVG:         {}'.format((sum_winter + sum_fall + sum_winter_2019)/(n_winter + n_fall + n_winter_2019)))

    print('N locations total', get_n_locations_total())


main()
