import os

import pandas as pd

from util import Semester, config


def count_updates_for_semester(semester: Semester) -> int:
    total = 0
    preprocessed_data_dir = os.path.join("data", "{}_location".format(semester))
    for preprocessed_data_file in os.listdir(preprocessed_data_dir):
        file_path = os.path.join(preprocessed_data_dir, preprocessed_data_file)
        df = pd.read_csv(file_path)
        total += len(df)
    return total


def main() -> None:
    total = 0
    for semester in Semester:
        if config.N_SEMESTERS == 3 or semester != Semester.WINTER_2019:
            total += count_updates_for_semester(semester)
    print(total)


if __name__ == "__main__":
    main()
