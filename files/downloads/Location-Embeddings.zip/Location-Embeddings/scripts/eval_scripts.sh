## One-Hot Avg
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_method weighted_average_ignore_short --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist --onehot

# Loc2V
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_size 25 --window_size 5 --epochs 5 --skip_gram --negative 20 --mult --vector_method weighted_average_ignore_short --hour_chunks --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist


# Twitter
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_method weighted_average_ignore_short --only_text_embeddings --text_embedding_methods twitter_geo.tfidf_pretrained.glove_twitter --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist

# Reddit
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_method weighted_average_ignore_short --only_text_embeddings --text_embedding_methods reddit_mention.tfidf_pretrained.glove_twitter --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist

# Campus-Website
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_method weighted_average_ignore_short --only_text_embeddings --text_embedding_methods campus_info.tfidf_pretrained.glove_twitter --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist


### combo part
# Loc2V-Reddit
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_method weighted_average_ignore_short --hour_chunks --mult --text_embedding_methods reddit_mention.tfidf_pretrained.glove_twitter --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist --vector_size 25 --window_size 5 --epochs 5 --skip_gram --negative 20

# Reddit-Retrofit
PYTHONHASHSEED=0 PYTHONPATH=. python3 -W ignore scripts/test_suite.py --representation_level month --vector_method weighted_average_ignore_short --text_embedding_methods reddit_mention.tfidf_pretrained.glove_twitter --classifier SVM --kernel linear --balance_class_weight --tasks $1 --cross_validate_all --test --use_whitelist data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist --only_text_embeddings --retrofit_location_graph_weighted