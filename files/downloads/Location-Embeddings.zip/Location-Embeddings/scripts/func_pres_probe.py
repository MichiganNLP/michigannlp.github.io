import argparse
import logging
import sys
from multiprocessing.pool import Pool

from evaluation.surface_level_probing import prep_embeddings, functionality_presence_multiple
from util.prep_location_embeddings import get_location_embeddings, get_multiple_location_embeddings


def process_method(method_name, vec_seq_list):
    print("Starting", method_name)
    sys.stdout.flush()
    functionality_presence_multiple(vec_seq_list, print_results=False)
    print("Done", method_name)
    sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        default='INFO',
                        help='Set the logging level')

    args = parser.parse_args()
    if args.log:
        logging.basicConfig(level=getattr(logging, args.log))

    # this was running in a notebook, but it would take ~35 hours to complete, so moving it to a script seems reasonable
    whitelist = 'data/building_whitelists/location_twitter_reddit_mention_campus_info.whitelist'

    onehot, _ = get_location_embeddings(use_whitelist=whitelist, onehot=True, seed=884)

    w2v_base_embedding_list, _ = get_multiple_location_embeddings(use_whitelist=whitelist, skip_gram=True,
                                                                  vector_size=25, window_size=5, epochs=5, negative=20)

    w2v_hr_embedding_list, _ = get_multiple_location_embeddings(use_whitelist=whitelist, skip_gram=True, vector_size=25,
                                                                window_size=5, epochs=5, negative=20, hour_chunks=True)

    twitter_geo_embeddings, _ = get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                                        text_embedding_methods=[
                                                            'twitter_geo.tfidf_pretrained.glove_twitter'])

    reddit_embeddings, _ = get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                                   text_embedding_methods=[
                                                       'reddit_mention.tfidf_pretrained.glove_twitter'])

    campus_info_embeddings, _ = get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                                        text_embedding_methods=[
                                                            'campus_info.tfidf_pretrained.glove_twitter'])

    reddit_concat_embedding_list, _ = get_multiple_location_embeddings(use_whitelist=whitelist, text_embedding_methods=[
        'reddit_mention.tfidf_pretrained.glove_twitter'], skip_gram=True, vector_size=25, window_size=5, epochs=5,
                                                                       negative=20)

    reddit_retrofit_embeddings, _ = get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                                            text_embedding_methods=[
                                                                'reddit_mention.tfidf_pretrained.glove_twitter'],
                                                            retrofit_location_graph=True)

    reddit_concat_hr_embedding_list, _ = get_multiple_location_embeddings(use_whitelist=whitelist,
                                                                          text_embedding_methods=[
                                                                              'reddit_mention.tfidf_pretrained.glove_twitter'],
                                                                          skip_gram=True, vector_size=25, window_size=5,
                                                                          epochs=5, negative=20, hour_chunks=True)

    reddit_retrofit_embeddings_weighted, _ = get_location_embeddings(only_text_embeddings=True, use_whitelist=whitelist,
                                                                     text_embedding_methods=[
                                                                         'reddit_mention.tfidf_pretrained.glove_twitter'],
                                                                     retrofit_location_graph_weighted=True)

    method_to_emb = {
        "one_hot": onehot,
        "w2v_base": w2v_base_embedding_list,
        "w2v_hr": w2v_hr_embedding_list,
        "twitter_geo": twitter_geo_embeddings,
        "reddit": reddit_embeddings,
        "campus_info": campus_info_embeddings,
        "reddit_concat": reddit_concat_embedding_list,
        "reddit_concat_hr": reddit_concat_hr_embedding_list,
        "reddit_retrofit": reddit_retrofit_embeddings,
        "reddit_retrofit_weighted": reddit_retrofit_embeddings_weighted,
    }

    method_to_vectors_and_sequences = {}
    for method, emb in method_to_emb.items():
        if type(emb) == list:
            vec_seq_list = []
            for ind_emb in emb:
                vec_seq_list.append(prep_embeddings(ind_emb))
            method_to_vectors_and_sequences[method] = vec_seq_list
        else:
            method_to_vectors_and_sequences[method] = [prep_embeddings(emb)]

    with Pool(5) as p:
        p.starmap(process_method, method_to_vectors_and_sequences.items())


if __name__ == '__main__':
    main()
