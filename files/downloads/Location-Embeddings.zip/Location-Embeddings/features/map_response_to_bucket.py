from util import num_text_map
from util.config import GENDER_QUESTION_ID, CLASS_YEAR_QUESTION_ID

def map_to_bucket(task, response):
    return get_bucket_mapping_fn(task)(response)


def get_bucket_mapping_fn(task):
    if task == 'class_year':
        return map_class_year_to_bucket
    if task == 'gender':
        return map_gender_to_bucket
    if task == 'sleep':
        return map_sleep_to_bucket
    if task == 'gpa':
        return map_gpa_to_bucket
    if task == 'school':
        return lambda x: x
    if task == 'depression_phq8_major':
        return map_depression_phq8_major_to_bucket
    if task == 'depression_phq8_all':
        return map_depression_phq8_all_to_bucket
    if task == 'depression_phq8_all_s4':
        return map_depression_phq8_all_to_bucket
    if task == 'depression_phq8_major_s4':
        return map_depression_phq8_major_to_bucket
    if task == 'gpa_cum':
        return map_gpa_to_bucket


def map_gender_to_bucket(gender_int):
    if str(gender_int) in num_text_map[GENDER_QUESTION_ID]:
        return num_text_map[GENDER_QUESTION_ID][str(gender_int)]


def map_class_year_to_bucket(class_int):
    return num_text_map[CLASS_YEAR_QUESTION_ID][str(class_int)]


def map_sleep_to_bucket(satisfaction):
    # we want to distinguish those who specify that they are dissatisfied by their sleep pattern
    return satisfaction >= 3


def map_gpa_to_bucket(gpa, binary=True):
    if binary:
        return gpa >= 3.5
    if gpa >= 3.5:
        return 'A'
    elif gpa < 2.5:
        return 'C'
    return 'B'


def map_depression_phq8_major_to_bucket(ternary_depression_indicator):
    return 1 if ternary_depression_indicator == 2 else 0


def map_depression_phq8_all_to_bucket(ternary_depression_indicator):
    return 1 if ternary_depression_indicator != 0 else 0
