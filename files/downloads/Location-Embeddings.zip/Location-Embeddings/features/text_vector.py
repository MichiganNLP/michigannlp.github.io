import argparse
import datetime
import itertools
import json
import os
import pickle
import re
from collections import defaultdict, Counter

import nltk
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

from util.enums import TextType, BuildingTextEmbeddingType
from util.load_embeddings import load, PretrainedEmbeddingType


BUILDING_TEXT_PATHS = {
    TextType.CAMPUS_INFO: 'text_embeddings/input_data/building_text.pickle',
    TextType.REDDIT_MENTION: 'text_embeddings/input_data/building_reddit_data_quality_control.pickle',
    TextType.TWITTER_GEO: 'text_embeddings/input_data/processed_geotagged_tweets.txt'
}

MENTION_BLACKLIST = ['building', 'hall', 'center', 'of', 'library', 'house', 'school', 'michigan', 'and', 'research',
                     'university', 'north', 'residence', 'arbor', 'institute', 'student', 'complex', 'campus', 'the',
                     'south', 'service', 'housing']

class TextEmbeddingBuilder:
    def __init__(self, text_type, pretrained_embedding_type, output_embedding_type):
        self.text_type = text_type
        self.pretrained_embedding_type = pretrained_embedding_type
        self.output_embedding_type = output_embedding_type

        # we will load the data when it is needed
        self._data = None

        # vocabulary is used when we do feature selection with KL divergence
        self.vocabulary = None

    ##### PROPERTIES ###################################################################################################

    @property
    def data(self):
        if self._data is None:
            self._data = self._load_data()
        return self._data

    ##### PROPERTIES ###################################################################################################

    ##### MAIN EXTERNAL FUNCTIONS TO CREATE AND SAVE EMBEDDINGS ########################################################

    def create_embeddings(self):
        # if using word2vec/glove, we need to restructure the text
        # we just return the restructured text instead of a word2vec embedding, so that we can test with multiple
        # initializations later
        if self.output_embedding_type == BuildingTextEmbeddingType.TFIDF_PRETRAINED:
            self.embeddings = self._create_embeddings_tfidf_pretrained()

    def save_embeddings(self):
        output_dir = os.path.join('text_embeddings', self.text_type.name.lower())
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        if self.pretrained_embedding_type is not None:
            output_filename = '{}.{}.pickle'.format(self.output_embedding_type.name.lower(),
                                                    self.pretrained_embedding_type.name.lower())
        else:
            output_filename = '{}.pickle'.format(self.output_embedding_type.name.lower())
        with open(os.path.join(output_dir, output_filename), 'wb') as f:
            pickle.dump(self.embeddings, f)

    ##### MAIN EXTERNAL FUNCTIONS TO CREATE AND SAVE EMBEDDINGS ########################################################

    ##### FUNCTIONS TO LOAD ALL TYPES OF DATA FROM DISC ################################################################

    def _load_data(self):
        return self._load_data_helper(self.text_type)

    def _load_data_helper(self, text_type):
        # format: building name -> list of words
        if text_type == TextType.CAMPUS_INFO:
            return self._load_data_campus_info()
        elif text_type == TextType.REDDIT_MENTION:
            return self._load_data_reddit(text_type)
        elif text_type == TextType.TWITTER_GEO or text_type == TextType.TWITTER_SEARCH:
            return self._load_data_twitter(text_type)
        else:
            raise Exception('Unsupported text type')

    def _load_data_reddit_ids(self):
        with open(BUILDING_TEXT_PATHS[TextType.REDDIT_MENTION], 'rb') as f:
            building_data = pickle.load(f)

        reddit_data = self._load_data_reddit(TextType.REDDIT_MENTION)
        return self._replace_tokens_with_ids(reddit_data, building_data)

    @staticmethod
    def _load_data_campus_info():
        with open(BUILDING_TEXT_PATHS[TextType.CAMPUS_INFO], 'rb') as f:
            data = pickle.load(f)
        # loop through and get rid of repetitive newlines
        filtered_data = defaultdict(list)
        for key in data.keys():
            valid_data = []
            for i in range(len(data[key])):
                if '%PDF' not in data[key][i]:
                    # filter out PDFs, bad quality text
                    valid_data.append(re.sub('\n+', '\n', data[key][i]))
            if len(valid_data) > 0:
                for word in nltk.word_tokenize('\n'.join(valid_data)):
                    if re.match('^[A-z0-9]*$', word):
                        filtered_data[key].append(word)
        return filtered_data

    def _load_data_reddit(self, text_type):
        intermediate_file = 'text_embeddings/intermediate/{}.pickle'.format(text_type.name.lower())
        if os.path.exists(intermediate_file):
            with open(intermediate_file, 'rb') as f:
                return pickle.load(f)

        with open(BUILDING_TEXT_PATHS[text_type], 'rb') as f:
            data = pickle.load(f)

        reddit_data = defaultdict(list)
        for building, nickname_map in data.items():
            seen_threads = set()
            for thread in itertools.chain(*nickname_map.values()):
                if thread['id'] in seen_threads:
                    continue
                seen_threads.add(thread['id'])

                tokenized_body = nltk.word_tokenize(thread['body'])
                if not text_type == TextType.REDDIT_MENTION or \
                        self._has_mention(tokenized_body, nickname_map.keys()):
                    reddit_data[building].extend(nltk.word_tokenize(thread['title']))
                    reddit_data[building].extend(tokenized_body)
                # for now, we can ignore the comment level
                for comments in thread['comments'].values():
                    for comment in comments:
                        tokenized_comment = nltk.word_tokenize(comment)
                        if not text_type == TextType.REDDIT_MENTION or \
                                self._has_mention(tokenized_comment, nickname_map.keys()):
                            reddit_data[building].extend(tokenized_comment)

        with open(intermediate_file, 'wb') as f:
            pickle.dump(reddit_data, f)
        return reddit_data

    def _load_data_twitter(self, text_type):
        if text_type == TextType.TWITTER_SEARCH:
            raise NotImplementedError()

        twitter_location_data = defaultdict(list)
        with open(BUILDING_TEXT_PATHS[text_type], 'r') as f:
            for line in f.read().splitlines():
                tweet_json = json.loads(line)
                tokenized_tweet = nltk.word_tokenize(tweet_json.get('full_text', tweet_json.get('text')))
                twitter_location_data[tweet_json['LEAP_location']].extend(tokenized_tweet)
        return twitter_location_data
    ##### FUNCTIONS TO LOAD ALL TYPES OF DATA FROM DISC ################################################################

    ##### FUNCTIONS USED TO CREATE DIFFERENT TYPES OF VECTORS FOR BUILDINGS ############################################
    def _create_embeddings_tfidf_pretrained(self):
        df = self._get_tfidf_dataframe()
        pretrained_embeddings = load(self.pretrained_embedding_type)
        doc_embeddings = {}
        for doc, vector in df.iterrows():
            doc_vector = np.zeros(pretrained_embeddings.vector_size)
            for word in vector.index:
                if vector[word] > 0 and self._word_in_vocab(pretrained_embeddings, word.lower()):
                    # add pretrained embedding, weighted by tf-idf
                    if hasattr(pretrained_embeddings, 'vectors'):
                        doc_vector += (pretrained_embeddings.vectors[word.lower()] * vector[word.lower()])
                    else:
                        doc_vector += (pretrained_embeddings[word.lower()] * vector[word.lower()])
            doc_embeddings[doc] = doc_vector
        return doc_embeddings

    def _get_tfidf_dataframe(self, limit=None):
        vectorizer = TfidfVectorizer(max_features=limit, vocabulary=self.vocabulary)
        tfidf_matrix = vectorizer.fit_transform(' '.join(val) for val in self.data.values())
        docs = list(self.data.keys())
        df = pd.DataFrame(tfidf_matrix.toarray(), index=docs, columns=vectorizer.get_feature_names())
        return df

    ##### FUNCTIONS USED TO CREATE DIFFERENT TYPES OF VECTORS FOR BUILDINGS ############################################

    ##### STATIC UTILITY METHODS #######################################################################################
    @staticmethod
    def _word_in_vocab(embeddings, word):
        if hasattr(embeddings, 'vectors'):
            return word.lower() in embeddings.vectors
        return word.lower() in embeddings

    @staticmethod
    def _has_mention(tokenized_text, nicknames):
        for word in tokenized_text:
            # a blacklist is used to remove words that appear in too many nicknames
            # we also do not search using very short words
            if word in MENTION_BLACKLIST or len(word) < 2:
                continue
            for nickname in nicknames:
                nickname_words = nickname.split()
                for nickname_word in nickname_words:
                    if word.lower() == nickname_word.lower():
                        return True
        return False

    @staticmethod
    def _replace_tokens_with_ids(data_map, name_id_map):
        tokenized_name_map = {}
        for data_id, names in name_id_map.items():
            if len(names) > 0:
                tokenized_names = [nltk.word_tokenize(word.lower()) for word in names]
                tokenized_name_map[data_id] = sorted(tokenized_names, key=lambda x: len(x), reverse=True)

        building_counts = Counter()
        building_tokens_processed = {}
        for i, (building_id, tokens) in enumerate(data_map.items()):
            print(datetime.datetime.now(), 'Processing', building_id, i / len(data_map))
            if len(tokens) == 0 or building_id not in tokenized_name_map:
                continue

            lowercase_tokens = [token.lower() for token in tokens]
            for tokenized_name in tokenized_name_map[building_id]:
                new_tokens = []
                idx = 0

                # to make this faster, start by checking that the first word is in the text list
                for token in tokenized_name:
                    if token.lower() not in lowercase_tokens:
                        continue

                while idx < len(tokens):
                    match = False
                    if idx + len(tokenized_name) > len(tokens):
                        # in this case we will go off the end of the list
                        new_tokens.extend(tokens[idx:])
                        break
                    for j in range(len(tokenized_name)):
                        if tokenized_name[j].lower() == tokens[idx + j].lower():
                            if j == len(tokenized_name) - 1:
                                # if we get to the last token and it matches, there is an overall match
                                match = True
                        else:
                            break
                    if match:
                        new_tokens.append(building_id)
                        idx += len(tokenized_name)
                        building_counts[building_id] += 1
                    else:
                        new_tokens.append(tokens[idx])
                        idx += 1
                tokens = new_tokens
            if building_counts[building_id] > 0:
                building_tokens_processed[building_id] = tokens
        return building_tokens_processed
    ##### STATIC UTILITY METHODS #######################################################################################


def _parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--text_type', choices=TextType, type=TextType.from_string, required=True,
                        help='type of text used to create embeddings')
    parser.add_argument('--output_embedding_type', choices=BuildingTextEmbeddingType,
                        type=BuildingTextEmbeddingType.from_string, required=True,
                        help='Method to use to create embeddings based on text')
    parser.add_argument('--pretrained_embedding_type', choices=PretrainedEmbeddingType,
                        type=PretrainedEmbeddingType.from_string,
                        help='Type of pretrained embeddings to be used (if needed)')
    args = parser.parse_args()

    # check that pretrained embedding type is specified when using pretrained
    if args.output_embedding_type == BuildingTextEmbeddingType.TFIDF_PRETRAINED:
        if args.pretrained_embedding_type is None:
            parser.error('Pretrained embedding type is required when outputting pretrained tfidf')
    else:
        # in this case, pretrained embedding type should not be used
        if args.pretrained_embedding_type is not None:
            parser.error('Pretrained embedding type should not be used unless outputting pretrained tfidf')
    return args


def main():
    args = _parse_args()
    embedding_builder = TextEmbeddingBuilder(args.text_type, args.pretrained_embedding_type, args.output_embedding_type)
    embedding_builder.create_embeddings()
    embedding_builder.save_embeddings()


if __name__ == '__main__':
    main()
