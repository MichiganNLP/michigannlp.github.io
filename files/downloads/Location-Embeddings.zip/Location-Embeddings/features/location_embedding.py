import argparse
import os
import pickle
import random
from collections import Counter

import pandas as pd
from gensim.models import Word2Vec

import util
from util import config, Semester


class BuildingEmbeddingBuilder:
    def __init__(self, functionality_map, skip_gram=config.DEFAULT_WORD2VEC_SKIP_GRAM,
                 vector_size=config.DEFAULT_WORD2VEC_VECTOR_SIZE, negative=config.DEFAULT_WORD2VEC_NEGATIVE_SAMPLING,
                 epochs=config.DEFAULT_WORD2VEC_EPOCHS, window_size=config.DEFAULT_WORD2VEC_WINDOW_SIZE,
                 hour_chunks=config.DEFAULT_HOUR_CHUNKS, seed=None, filter_stopwords=False, replace_infrequent=0,
                 file_index=None, min_duration_sec=600):
        self.functionality_map = functionality_map
        self.skip_gram = 1 if skip_gram else 0
        self.vector_size = vector_size
        self.hour_chunks = hour_chunks
        self.filter_stopwords = filter_stopwords
        self.negative = negative
        self.replace_infrequent = replace_infrequent
        self.epochs = epochs
        self.file_index = file_index
        self.window_size = window_size
        self.restricted_words = set()
        self.min_duration = min_duration_sec
        self.seed = seed
        self.model = None
        self.sequences = self.generate_sequences()

    def get_outfile_name(self):
        sg = '_skip_gram' if self.skip_gram else '_cbow'
        hc = '_hour_chunks' if self.hour_chunks else ''
        vs = '_vector_size_{}'.format(self.vector_size)
        ng = '_negative_{}'.format(self.negative)
        ri = '_replace_infrequent_{}'.format(self.replace_infrequent) if self.replace_infrequent != 0 else ''
        ep = '_epochs_{}'.format(self.epochs)
        fi = f'.{self.file_index}' if self.file_index is not None else ''
        ws = '_window_size_{}'.format(self.window_size)

        if self.file_index:
            return 'building_embeddings_duplicates/embeddings{}{}{}{}{}{}{}{}.pickle'.format(vs, ng, sg, hc, ri, ep,
                                                                                                 fi, ws)
        return 'building_embeddings/embeddings{}{}{}{}{}{}{}.pickle'.format(vs, ng, sg, hc, ri, ep, ws)

    def generate_sequences(self):
        if self.hour_chunks:
            sequences = self.generate_sequences_hour_chunks()
        else:
            sequences = self.generate_sequences_default()
        if self.replace_infrequent != 0:
            count_sequences = Counter()
            for sequence in sequences:
                sequence_presence = set(sequence)
                count_sequences.update(sequence_presence)
            for s_id, sequence in enumerate(sequences):
                for w_id, word in enumerate(sequence):
                    if count_sequences[word] < self.replace_infrequent and word != 'external':
                        sequences[s_id][w_id] = self.functionality_map[word]
        return sequences

    def generate_sequences_default(self):
        sequences = []
        for csv_path in util.get_location_csv_paths():
            df = pd.read_csv(csv_path)
            text = []
            for row in df.itertuples():
                if row.Duration >= self.min_duration:
                    if row.Location != 'external':
                        text.append(row.Location)
                        self.restricted_words.add(row.Location)
            sequences.append(text)
        return sequences

    def generate_sequences_hour_chunks(self):
        pickle_file = 'resources/hour_chunk_sequences'
        # load restricted words
        pickle_file_restricted_words = pickle_file + 'rw.pickle'
        pickle_file += '.pickle'
        if os.path.isfile(pickle_file_restricted_words):
            with open(pickle_file_restricted_words, 'rb') as pickled_rw:
                self.restricted_words = pickle.load(pickled_rw)
            if os.path.isfile(pickle_file):
                with open(pickle_file, 'rb') as pickled_sequences:
                    return pickle.load(pickled_sequences)

        # treat each hour as a distinct chunk of time when generating sequences
        # there is always a location for that time chunk
        sequences = []
        for semester in Semester:
            for csv_path in util.get_location_csv_paths(semester=semester):
                df = pd.read_csv(csv_path)
                text, restricted_words = util.build_hour_chunks(df, semester, include_unknown=True)
                self.restricted_words.update(restricted_words)
                sequences.append(text)

        with open(pickle_file, 'wb') as handle:
            pickle.dump(sequences, handle)
        with open(pickle_file_restricted_words, 'wb') as handle:
            pickle.dump(self.restricted_words, handle)
        return sequences

    def train(self):
        model = Word2Vec(self.sequences, sg=self.skip_gram, size=self.vector_size, negative=self.negative,
                         iter=self.epochs, window=self.window_size, seed=self.seed, workers=(1 if self.seed else 4))
        self.model = model
        return model


def _parse_args():
    parser = argparse.ArgumentParser(description="Build embeddings of buildings using student's location data")
    parser.add_argument('--skip_gram', action='store_true', default=False)
    parser.add_argument('--vector_size', type=int, default=100)
    parser.add_argument('--hour_chunks', action='store_true', default=False,
                        help='Build vectors with each hour of the 24-hour day')
    parser.add_argument('--output_model', action='store_true', default=False)
    parser.add_argument('--filter_stopwords', action='store_true', default=False)
    parser.add_argument('--negative', type=int, default=0)
    parser.add_argument('--replace_infrequent', type=int, default=0,
                        help='If less than n students have visiting a building, remove it from calculations and replace'
                             ' it with its functionality')
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--index', type=int,
                        help='This is used in the file name if a duplicate pickle file is being created')
    parser.add_argument('--window_size', type=int, default=5)

    args = parser.parse_args()
    return args


def main():
    args = _parse_args()
    functionality_map = util.get_functionalities(single=True)
    builder = BuildingEmbeddingBuilder(functionality_map, skip_gram=args.skip_gram, vector_size=args.vector_size,
                                       negative=args.negative, epochs=args.epochs, window_size=args.window_size,
                                       hour_chunks=args.hour_chunks, filter_stopwords=args.filter_stopwords,
                                       replace_infrequent=args.replace_infrequent, file_index=args.index)
    model = builder.train()
    if args.output_model:
        filename = builder.get_outfile_name()
        with open(filename, 'wb') as handle:
            pickle.dump(model, handle)
            print(f'Saved model to {filename}')
    return model


if __name__ == '__main__':
    main()
