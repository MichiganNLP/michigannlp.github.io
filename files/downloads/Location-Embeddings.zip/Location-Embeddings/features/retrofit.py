# adapted from https://github.com/mfaruqui/retrofitting/blob/master/retrofit.py

import argparse
import gzip
import math
import re
import sys
from copy import deepcopy

import numpy
from gensim.models import Word2Vec

from util import util

isNumber = re.compile(r'\d+.*')


def norm_word(word):
    if isNumber.search(word.lower()):
        return '---num---'
    elif re.sub(r'\W+', '', word) == '':
        return '---punc---'
    else:
        return word.lower()


''' Read all the word vectors and normalize them '''
def read_word_vecs(filename):
    wordVectors = {}
    if filename.endswith('.gz'):
        fileObject = gzip.open(filename, 'r')
    else:
        fileObject = open(filename, 'r')

    for line in fileObject:
        line = line.strip().lower()
        word = line.split()[0]
        wordVectors[word] = numpy.zeros(len(line.split()) - 1, dtype=float)
        for index, vecVal in enumerate(line.split()[1:]):
            wordVectors[word][index] = float(vecVal)
    # normalize weight vectors
    normalizedVectors = normalize_weight_vectors(wordVectors)

    sys.stderr.write("Vectors read from: " + filename + " \n")
    return normalizedVectors


def normalize_weight_vectors(word_vectors):
    normalized_vectors = {}
    for word in word_vectors:
        normalized_vectors[word] = word_vectors[word] / math.sqrt((word_vectors[word] ** 2).sum() + 1e-6)
    return normalized_vectors


''' Write word vectors to file '''
def print_word_vecs(wordVectors, outFileName):
    sys.stderr.write('\nWriting down the vectors in ' + outFileName + '\n')
    outFile = open(outFileName, 'w')
    for word, values in wordVectors.iteritems():
        outFile.write(word + ' ')
        for val in wordVectors[word]:
            outFile.write('%.4f' % val + ' ')
        outFile.write('\n')
    outFile.close()


''' Read the PPDB word relations as a dictionary '''
def read_lexicon(filename):
    lexicon = {}
    for line in open(filename, 'r'):
        words = line.lower().strip().split()
        lexicon[norm_word(words[0])] = [norm_word(word) for word in words[1:]]
    return lexicon


''' Retrofit word vectors to a lexicon '''
def retrofit(wordVecs, lexicon, numIters, lexiconWeights=None):
    newWordVecs = deepcopy(wordVecs)
    wvVocab = set(newWordVecs.keys())
    loopVocab = wvVocab.intersection(set(lexicon.keys()))
    for it in range(numIters):
        # loop through every node also in ontology (else just use data estimate)
        for word in loopVocab:
            wordNeighbours = set(lexicon[word]).intersection(wvVocab)
            numNeighbours = len(wordNeighbours)
            alphaBetaSum = numNeighbours if lexiconWeights is None else sum(lexiconWeights[word].values())
            # no neighbours, pass - use data estimate
            if numNeighbours == 0:
                continue
            # the weight of the data estimate if the number of neighbours
            newVec = alphaBetaSum * wordVecs[word]
            # loop over neighbours and add to new vector (currently with weight 1)
            for ppWord in wordNeighbours:
                weight = 1 if lexiconWeights is None else lexiconWeights[word][ppWord]
                newVec += weight * newWordVecs[ppWord]
            newWordVecs[word] = newVec / (2 * alphaBetaSum)
    return newWordVecs


def retrofit_location_graph(vectors, n_iters=10, use_weights=False):
    vectors = normalize_weight_vectors(vectors)
    lexicon, lexiconWeights = util.generate_movement_lexicon()
    if use_weights:
        return retrofit(vectors, lexicon, n_iters, lexiconWeights=lexiconWeights)
    else:
        return retrofit(vectors, lexicon, n_iters)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", type=str, default=None, help="Input word vecs")
    parser.add_argument("-l", "--lexicon", type=str, default=None, help="Lexicon file name")
    parser.add_argument("-o", "--output", type=str, help="Output word vecs")
    parser.add_argument("-n", "--numiter", type=int, default=10, help="Num iterations")
    args = parser.parse_args()

    wordVecs = read_word_vecs(args.input)
    lexicon = read_lexicon(args.lexicon)
    numIter = int(args.numiter)
    outFileName = args.output

    ''' Enrich the word vectors using ppdb and print the enriched vectors '''
    print_word_vecs(retrofit(wordVecs, lexicon, numIter), outFileName)
