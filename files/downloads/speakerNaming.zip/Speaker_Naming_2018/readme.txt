Speaker Naming Dataset

This dataset contains subtitles of 18 movies and 6 episodes of the Big Bang Theory TV show with each segment manually annotated with its corresponding speaker name.
It is described in the paper

Speaker Naming in Movies. Mahmoud Azab, Mingzhe Wang, Max Smith, Noriyuki Kojimana, Jia Deng, Rada Mihalcea. 
In proceedings of The 2018 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies (NAACL/HLT 2018), Louisiana, USA, June 2018.

and can be downloaded at: http://lit.eecs.umich.edu/downloads.html

This dataset is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License (see LICENSE).

Under subtitles/ each file consists of a list of subtitles segment. The file names represent the movie imdb id in addition to bbt_episode_number for the Big Bang Theory. 

Each subtitle segment has the following format:

[ speaker_name,    segment_id, duration, text, "begin_time_stamp --> end_time_stamp"]
    - speaker_name: the name of the character uttered the subtitle segment
    - segment_id  : the id of the subtitles segment
    - duration    : the duration of the subtitle segment on the screen
    - text        : the utterance being said by the speaker
    - "begin_time_stamp --> end_time_stamp": the begin and end time stamps of the subtitle segments in the format HH:MM:SS,ms


For example in file tt0129387.srt (There's Something About Mary) movie:
    ["Ted",    36,  2,  "I 'm gonna hold you to that .",   "00:03:57,372 --> 00:03:59,432" ]




